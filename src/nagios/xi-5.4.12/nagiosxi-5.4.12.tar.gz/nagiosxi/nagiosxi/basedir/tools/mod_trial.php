#!/usr/bin/php -q
<?php
//
// Nagios XI Trial Extension Tool
// Copyright (c) 2017 Nagios Enterprises, LLC.
//  

define("SUBSYSTEM", 1);

require_once('/usr/local/nagiosxi/html/config.inc.php');
require_once('/usr/local/nagiosxi/html/includes/utilsl.inc.php');

doit();

function doit()
{
    global $argv;

    $option = "";
    $value = "";
    $have_value = false;

    $args = parse_argv($argv);
    $key = grab_array_var($args, "key");

    if (empty($key)) {
        echo "Nagios XI Trial Extension Tool\n";
        echo "Copyright (c) 2017 Nagios Enterprises, LLC\n";
        echo "\n";
        echo "Usage: ".$argv[0]." --key=<key>\n";
        echo "\n";
        exit(1);
    }

    // Connect to database
    $dbok = db_connect_all();
    if ($dbok == false) {
        echo "ERROR CONNECTING TO DATABASES!\n";
        exit();
    }

    if (extend_trial($key)) {
        echo "Trial key applied.\n";
        exit(0);
    } else {
        echo "Invalid trial key.\n";
        exit(1);
    }
}
