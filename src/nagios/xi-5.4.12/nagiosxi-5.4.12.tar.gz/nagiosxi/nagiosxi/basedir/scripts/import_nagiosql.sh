#!/bin/bash
# Copyright (c) 2008-2016 Nagios Enterprises, LLC.  All rights reserved.

BASEDIR=$(dirname $(readlink -f $0))

# Login to NagiosQL
/usr/bin/php -q $BASEDIR/nagiosql_login.php

#error handling
ret=$?
if [ $ret -gt 0 ]; then
	echo "NAGIOSQL LOGIN FAILED!"
	exit $ret
fi

# Import all data
/usr/bin/php -q $BASEDIR/nagiosql_importall.php

ret=$?
if [ $ret -gt 0 ]; then
	echo "NAGIOSQL IMPORT FAILED!"
	exit $ret
fi