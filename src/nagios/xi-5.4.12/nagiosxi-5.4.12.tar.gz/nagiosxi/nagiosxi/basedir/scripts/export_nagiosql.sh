#!/bin/bash
# Copyright (c) 2008-2016 Nagios Enterprises, LLC.  All rights reserved.

BASEDIR=$(dirname $(readlink -f $0))

# Fix permissions on config files to make sure NagiosQL can write data
sudo $BASEDIR/reset_config_perms.sh

#error handling
ret=$?
if [ $ret -gt 0 ]; then
	echo "RESETTING CONFIG PERMS FAILED!\n"
	exit 4
fi

# Login to NagiosQL
/usr/bin/php -q $BASEDIR/nagiosql_login.php

#error handling
ret=$?
if [ $ret -gt 0 ]; then
	echo "NAGIOSQL LOGIN FAILED!\n"
	exit $ret
fi

# Export all data
/usr/bin/php -q $BASEDIR/nagiosql_exportall.php

#error handling
ret=$?
if [ $ret -gt 0 ]; then
	echo "NAGIOSQL WRITE CONFIGS FAILED!\n"
	exit $ret
fi