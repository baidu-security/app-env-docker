<?php
/**
 *
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Sales\Controller\AbstractController;

abstract class Invoice extends \Magento\Sales\Controller\AbstractController\View
{
}
