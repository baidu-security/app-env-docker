Magento\Variable Allows to create custom variables and then use them in email templates or in WYSIWYG editor for editing description of system entities.
