<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magento\GiftMessage\Test\Block\Adminhtml\Order\Create;

/**
 * Backend GiftMessage for order form.
 */
class GiftOptions extends \Magento\Mtf\Block\Form
{
    //
}
