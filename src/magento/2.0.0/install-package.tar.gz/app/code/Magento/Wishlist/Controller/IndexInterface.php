<?php
/**
 *
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Wishlist\Controller;

use Magento\Catalog\Controller\Product\View\ViewInterface;

interface IndexInterface extends \Magento\Framework\App\ActionInterface, ViewInterface
{
}
