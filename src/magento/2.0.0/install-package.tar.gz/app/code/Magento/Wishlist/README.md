The Magento_Wishlist implements the Wishlist functionality.
This allows customers to create a list of products that they can add to their shopping cart to be purchased at a later date, or share with friends.
