<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

/**
 * Delete item column in customer wishlist table
 *
 * @author      Magento Core Team <core@magentocommerce.com>
 */
namespace Magento\Wishlist\Block\Customer\Wishlist\Item\Column;

class Remove extends \Magento\Wishlist\Block\Customer\Wishlist\Item\Column
{
}
