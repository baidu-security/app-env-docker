# Overview
## Purpose of module

The Magento\RequireJs module introduces support for RequireJs JavaScript library and provides infrastructure for other modules to have them declared related configuration for RequireJs library.

# Deployment
## System requirements

The Magento\RequireJs module does not have any specific system requirements.

## Install
The Magento\RequireJs module is installed automatically (using the native Magento Setup). No additional actions required.
