<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magento\Braintree\Test\Unit\Controller\Stub;

class MyCreditCardsStub extends \Magento\Braintree\Controller\MyCreditCards
{
    public function execute()
    {
        // Empty method stub for test
    }
}
