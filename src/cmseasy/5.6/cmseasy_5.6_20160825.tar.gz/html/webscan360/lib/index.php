<?php
exit("no access!");