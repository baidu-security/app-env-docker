<?php

if (!defined('ROOT')) exit('Can\'t Access !');
class table_zanlog extends table_mode {
}