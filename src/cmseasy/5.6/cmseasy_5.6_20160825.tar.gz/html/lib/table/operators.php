<?php

class operators extends table {
}