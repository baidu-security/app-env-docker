<?php

class union_visit extends table {
}