<?php

if (!defined('ROOT')) exit('Can\'t Access !');
class table_orders  extends table_mode {

}