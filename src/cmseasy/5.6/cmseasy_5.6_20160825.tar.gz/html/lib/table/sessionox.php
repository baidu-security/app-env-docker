<?php
class sessionox extends table {
	function getcols($act) {
	}
}