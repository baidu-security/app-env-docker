<?php

class union_pay extends table {

}