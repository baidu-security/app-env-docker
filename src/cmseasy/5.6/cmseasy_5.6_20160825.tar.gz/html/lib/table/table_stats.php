<?php

if (!defined('ROOT')) exit('Can\'t Access !');
class table_stats  extends table_mode {
}