// JavaScript Document
function sendjs(){
	document.write("<script src='http://info.cmseasy.net/server/js/celive/client/chatboxinf.js'><\/script>"); 
}
sendjs();