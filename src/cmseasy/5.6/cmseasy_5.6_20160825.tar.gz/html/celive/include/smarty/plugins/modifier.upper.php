<?php

function smarty_modifier_upper($string)
{
return strtoupper($string);
}

?>