<?php

$n = file_get_contents('../../admin/live/cookie.inc');
echo $n;

?>