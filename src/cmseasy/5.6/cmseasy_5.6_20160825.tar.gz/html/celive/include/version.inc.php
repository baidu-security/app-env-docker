<?php

$config['version'] = '1.2.0';
$config['release'] = '20100707';

?>