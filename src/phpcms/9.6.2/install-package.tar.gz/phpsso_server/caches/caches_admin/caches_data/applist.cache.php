<?php
return array (
  1 => 
  array (
    'appid' => '1',
    'type' => 'phpcms_v9',
    'name' => 'phpcms v9',
    'url' => 'http://172.17.0.2/',
    'authkey' => 'poBIfkDQG9Rv1uYsRAvt5H6dwgszXHFg',
    'ip' => '',
    'apifilename' => 'api.php?op=phpsso',
    'charset' => 'utf-8',
    'synlogin' => '1',
  ),
);
?>