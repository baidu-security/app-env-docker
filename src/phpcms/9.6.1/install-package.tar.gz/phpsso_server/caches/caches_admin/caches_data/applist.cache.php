<?php
return array (
  1 => 
  array (
    'appid' => '1',
    'type' => 'phpcms_v9',
    'name' => 'phpcms v9',
    'url' => 'http://172.17.0.2/',
    'authkey' => 'lMS6RoBOFZHcUQiVtp0b1BIuY8ksgbPG',
    'ip' => '',
    'apifilename' => 'api.php?op=phpsso',
    'charset' => 'utf-8',
    'synlogin' => '1',
  ),
);
?>