<?php
return array (
  1 => 
  array (
    'appid' => '1',
    'type' => 'phpcms_v9',
    'name' => 'phpcms v9',
    'url' => 'http://172.17.0.2/',
    'authkey' => 'RYOGFEsWoOGfezQi6S4aER48bWonB5vb',
    'ip' => '',
    'apifilename' => 'api.php?op=phpsso',
    'charset' => 'utf-8',
    'synlogin' => '1',
  ),
);
?>