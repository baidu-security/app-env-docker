<?php
                   /*
                   con_db_host = "localhost"
                   con_db_port = "3306"
                   con_db_id   = "root"
                   con_db_pass	= ""
                   con_db_name = "metinfo"
                   tablepre    =  "met_"
                   db_charset  =  "utf8";
                  */
                  ?>