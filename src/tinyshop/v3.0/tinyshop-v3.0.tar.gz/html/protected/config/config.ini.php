<?php return array (
  'classes' =>
  array (
    0 => 'classes.*',
    1 => 'extensions.*',
    2 => 'classes.barcode.*',
    3 => 'classes.payments.*',
    4 => 'classes.delivery.*',
    5 => 'classes.oauth.*'
  ),
  'theme' => 'default',
  'urlFormat' => 'get',
  'db' =>
  array (
    'type' => 'mysql',
    'tablePre' => '',
    'host' => '',
    'user' => '',
    'prot' => '',
    'password' => '',
    'name' => '',
  ),
  'route' =>
  array (
  ),
  'extConfig' =>
  array (
    'controllerExtension' =>
    array (
      0 => 'ControllerExt',
    ),
  ),
);?>
