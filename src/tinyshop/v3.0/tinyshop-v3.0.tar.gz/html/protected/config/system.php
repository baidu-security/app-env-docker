<?php return array (
  'photo' => 
  array (
    'photo_width' => '13',
    'photo_small_width' => '13',
  ),
  'globals' => 
  array (
    'site_name' => 'TinyShop大型电子商务系统',
    'site_logo' => '',
    'site_keywords' => '泰创软件科技有限公司|Tiny系列产品',
    'site_description' => '工匠精神、细节、点滴、开源、高效、安全',
    'site_icp' => '',
    'site_url' => '',
    'site_addr' => '',
    'site_mobile' => '',
    'site_email' => '',
    'site_zip' => '',
    'site_phone' => '',
  ),
  'safe' => 
  array (
    'safe_reg_limit' => '0',
    'safe_reg_num' => '1',
    'safe_comment_limit' => '0',
    'safe_comment_num' => '2',
    'safe_album_limit' => '0',
    'safe_album_num' => '2',
    'safe_click_count' => '1',
  ),
  'email' => 
  array (
    'email_sendtype' => 'smtp',
    'email_host' => '',
    'email_ssl' => '',
    'email_port' => '',
    'email_account' => '',
    'email_password' => '',
    'email_sender_name' => '',
  ),
  'other' => 
  array (
    'other_currency_symbol' => '￥',
    'other_currency_unit' => '元',
    'other_is_invoice' => '1',
    'other_tax' => '6',
    'other_grade_days' => '365',
    'other_order_delay' => '120',
    'other_order_delay_flash' => '120',
    'other_order_delay_group' => '120',
    'other_order_delay_bund' => '0',
    'other_verification_eamil' => NULL,
  ),
);