<?php

// This is PHPDISK auto-generated file. Do NOT modify me.

$configs = array(

	'dbhost' => 'localhost',

	'dbname' => 'phpdisk',

	'dbuser' => 'root',

	'dbpasswd' => '',

	'pconnect' => 0,

	'tpf' => 'pd_',

	'charset' => 'utf-8',

	'debug' => '0',

);

define('ADMINCP','admincp');
?>
