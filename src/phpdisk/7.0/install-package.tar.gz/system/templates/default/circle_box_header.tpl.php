<?php 
// This is PHPDISK auto-generated file. Do NOT modify me.

// Cache Time:2018-07-23 20:18:00

!defined('IN_PHPDISK') && exit('[PHPDisk] Access Denied');

?>
<?php 
##
#	Project: PHPDISK File Storage Solution
#	This is NOT a freeware, use is subject to license terms.
#
#	Site: http://www.phpdisk.com
#
#	$Id: circle_box_header.tpl.php 25 2014-01-10 03:13:43Z along $
#
#	Copyright (C) 2008-2014 PHPDisk Team. All Rights Reserved.
#
##
 ?>
<?php !defined('IN_PHPDISK') && exit('[PHPDisk] Access Denied!'); ?>
<div class="user_box">
<b class="ctop">
<b class="cb1"></b><b class="cb2"></b><b class="cb3"></b><b class="cb4"></b>
</b>