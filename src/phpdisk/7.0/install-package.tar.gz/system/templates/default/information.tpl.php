<?php 
// This is PHPDISK auto-generated file. Do NOT modify me.

// Cache Time:2018-07-23 19:52:32

!defined('IN_PHPDISK') && exit('[PHPDisk] Access Denied');

?>
<?php 
##
#	Project: PHPDISK File Storage Solution
#	This is NOT a freeware, use is subject to license terms.
#
#	Site: http://www.phpdisk.com
#
#	$Id: information.tpl.php 25 2014-01-10 03:13:43Z along $
#
#	Copyright (C) 2008-2014 PHPDisk Team. All Rights Reserved.
#
##
 ?>
<?php !defined('IN_PHPDISK') && exit('[PHPDisk] Access Denied!'); ?>
<div class="info_box">
<div class="info_box_tit"><img src="images/light.gif" align="absmiddle" border="0" /> <?=__('tips_message')?></div>
<div class="info_box_msg">
<?=$msg?>
<div align="center"><a href="<?=$url?>"><?=__('click_to_back')?></a></div><br>
</div>
<br />

</div>