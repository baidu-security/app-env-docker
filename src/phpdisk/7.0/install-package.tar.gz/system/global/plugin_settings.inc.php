<?php

// This is PHPDISK auto-generated file. Do NOT modify me.
// Cache Time: 2018-07-23 19:51:10

$plugin_settings = array(
);

?>
