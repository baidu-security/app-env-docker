<?php

// This is PHPDISK auto-generated file. Do NOT modify me.
// Cache Time: 2018-07-23 19:51:10

$lang_settings = array(
	'zh_cn'=>array(
		'lang_name'=>'zh_cn',
		'actived'=>'1',
	),
);

?>
