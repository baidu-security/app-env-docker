<?php

// This is PHPDISK auto-generated file. Do NOT modify me.
// Cache Time: 2018-07-23 19:51:10

$group_settings = array(
	'1' => array(
		'max_messages' => '0',
		'max_flow_down' => '0',
		'max_flow_view' => '0',
		'max_storage' => '0',
		'max_filesize' => '0',
		'group_file_types' => '',
		'max_folders' => '0',
		'max_files' => '0',
		'can_share' => '1',
		'secs_loading' => '5',
		'server_ids' => '0',
	),

	'2' => array(
		'max_messages' => '0',
		'max_flow_down' => '10g',
		'max_flow_view' => '20g',
		'max_storage' => '0',
		'max_filesize' => '1m',
		'group_file_types' => '',
		'max_folders' => '0',
		'max_files' => '0',
		'can_share' => '1',
		'secs_loading' => '0',
		'server_ids' => '0',
	),

	'3' => array(
		'max_messages' => '0',
		'max_flow_down' => '0',
		'max_flow_view' => '0',
		'max_storage' => '0',
		'max_filesize' => '0',
		'group_file_types' => '',
		'max_folders' => '0',
		'max_files' => '0',
		'can_share' => '1',
		'secs_loading' => '0',
		'server_ids' => '1',
	),

	'4' => array(
		'max_messages' => '0',
		'max_flow_down' => '0',
		'max_flow_view' => '0',
		'max_storage' => '0',
		'max_filesize' => '0',
		'group_file_types' => '',
		'max_folders' => '0',
		'max_files' => '0',
		'can_share' => '1',
		'secs_loading' => '0',
		'server_ids' => '1',
	),

);

?>
