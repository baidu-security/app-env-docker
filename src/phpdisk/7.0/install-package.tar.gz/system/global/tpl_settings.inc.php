<?php

// This is PHPDISK auto-generated file. Do NOT modify me.
// Cache Time: 2018-07-23 19:51:10

$tpl_settings = array(
	'admin'=>array(
		'tpl_name'=>'admin',
		'actived'=>'1',
		'tpl_type'=>'admin',
	),
	'default'=>array(
		'tpl_name'=>'default',
		'actived'=>'1',
		'tpl_type'=>'user',
	),
);

?>
