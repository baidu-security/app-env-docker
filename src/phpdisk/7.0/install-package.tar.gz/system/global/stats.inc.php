<?php

// This is PHPDISK auto-generated file. Do NOT modify me.
// Cache Time: 2018-07-23 21:06:57

$stats = array(
	'all_files_count' => '0',
	'extract_code_count' => '0',
	'public_storage_count' => '0.0 B',
	'stat_time' => '1532351216',
	'total_storage_count' => '0.0 B',
	'users_count' => '2',
	'users_locked_count' => '0',
	'users_open_count' => '2',
	'user_files_count' => '0',
	'user_folders_count' => '0',
	'user_storage_count' => '0.0 B',
);

?>
