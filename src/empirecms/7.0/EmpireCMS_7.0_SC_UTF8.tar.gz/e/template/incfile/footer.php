<?php
if(!defined('InEmpireCMS'))
{
	exit();
}
?>
    </td>
  </tr>
</table>
<table width="960" border="0" align="center" cellpadding="3" cellspacing="1">
  <tr>
    <td height="8"></td>
  </tr>
</table>
<table width="960" height="2" border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="<?=$bgcolor_line?>">
  <tr>
    <td></td>
  </tr>
</table>
<table width="960" border="0" align="center" cellpadding="3" cellspacing="1">
  <tr>
    <td height="32"><div align="center">Powered by <strong><a href="http://www.phome.net" target="_blank">EmpireCMS</a></strong> 7.0&nbsp; &copy; 2002-2013 <a href="http://www.digod.com" target="_blank">EmpireSoft Inc.</a></div></td>
  </tr>
</table>
<?=EcmsShowThisMemberMenu()?>
</body>
</html>