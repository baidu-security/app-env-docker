<?php

define('EmpireCMS_VERSION','7.0');

define('EmpireCMS_CHARVER','UTF-8');

define('EmpireCMS_LASTTIME','201303301830');

define('EmpireCMS_UPDATE','1');

?>