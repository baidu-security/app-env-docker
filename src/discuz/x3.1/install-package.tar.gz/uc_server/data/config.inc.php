<?php 
define('UC_DBHOST', 'localhost');
define('UC_DBUSER', 'root');
define('UC_DBPW', '');
define('UC_DBNAME', 'ultrax');
define('UC_DBCHARSET', 'utf8');
define('UC_DBTABLEPRE', 'pre_ucenter_');
define('UC_COOKIEPATH', '/');
define('UC_COOKIEDOMAIN', '');
define('UC_DBCONNECT', 0);
define('UC_CHARSET', 'utf-8');
define('UC_FOUNDERPW', '944204272aad249b05369604222d20d7');
define('UC_FOUNDERSALT', 'mas7S8');
define('UC_KEY', 'HaF7I8g2M2B6o8t5E5q1A23bvcAcW0wax6ZcPcO0NaI3EcV6z8ca3apcV7Zakfh5');
define('UC_SITEID', 'uak7n852F2N6d8S5N591e2NbbclcS04a36dcEca0ya13icp6N8iaSaNcp7MaGfz5');
define('UC_MYKEY', 'saS7c8m2s2g6W8H5n5i1h23bdcoc90Da66ccGcE0jaR3Hc16A88a8aBcO7yaSfQ5');
define('UC_DEBUG', false);
define('UC_PPP', 20);
