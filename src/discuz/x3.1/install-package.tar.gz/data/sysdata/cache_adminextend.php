<?php
//Discuz! cache file, DO NOT modify me!
//Identify: a57f1c0dd6f568957b04b530759ac62b

$adminextend = array (
  0 => 'cloud.php',
);
?>