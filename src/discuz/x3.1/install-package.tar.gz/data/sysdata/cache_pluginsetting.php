<?php
//Discuz! cache file, DO NOT modify me!
//Identify: d27e458250f85553d75c9cb649079690

$pluginsetting = array (
);
?>