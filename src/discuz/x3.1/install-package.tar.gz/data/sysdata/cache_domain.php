<?php
//Discuz! cache file, DO NOT modify me!
//Identify: 3b79ffe27d1d92bb91c2e89d1b5a5c27

$domain = array (
  'defaultindex' => 'http://172.17.0.2/portal.php?mod=list&catid=1',
  'holddomain' => 'www|*blog*|*space*|*bbs*',
  'list' => 
  array (
  ),
  'app' => 
  array (
    'portal' => '',
    'forum' => '',
    'group' => '',
    'home' => '',
    'default' => '',
  ),
  'root' => 
  array (
    'home' => '',
    'group' => '',
    'forum' => '',
    'topic' => '',
    'channel' => '',
  ),
);
?>