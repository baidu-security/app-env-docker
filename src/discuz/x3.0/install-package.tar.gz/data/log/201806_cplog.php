<?PHP exit;?>	1528112015	admin	1	172.17.0.1		GET={}; POST={};
<?PHP exit;?>	1528112016	admin	1	172.17.0.1	index	GET={}; POST={};
<?PHP exit;?>	1528112026	admin	1	172.17.0.1	logout	GET={}; POST={};
