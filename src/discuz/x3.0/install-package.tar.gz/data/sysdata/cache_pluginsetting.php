<?php
//Discuz! cache file, DO NOT modify me!
//Identify: ab08e9c075720aafee73c59ca5a252d7

$pluginsetting = array (
);
?>