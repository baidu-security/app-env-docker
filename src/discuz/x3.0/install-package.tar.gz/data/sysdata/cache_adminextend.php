<?php
//Discuz! cache file, DO NOT modify me!
//Identify: 73596b46ce20e2eff82f4413cf5f9c8c

$adminextend = array (
  0 => 'cloud.php',
);
?>