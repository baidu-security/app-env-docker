<?php 
define('UC_DBHOST', 'localhost');
define('UC_DBUSER', 'root');
define('UC_DBPW', '');
define('UC_DBNAME', 'ultrax');
define('UC_DBCHARSET', 'utf8');
define('UC_DBTABLEPRE', 'pre_ucenter_');
define('UC_COOKIEPATH', '/');
define('UC_COOKIEDOMAIN', '');
define('UC_DBCONNECT', 0);
define('UC_CHARSET', 'utf-8');
define('UC_FOUNDERPW', 'a01b50433f6d517ae5101a35dfde2647');
define('UC_FOUNDERSALT', 'M0h6l9');
define('UC_KEY', '50D6y9O1M7f2G4k7J8KaUc2brfc3I5C5l4J9LbSag3h9qeM9x3R140A2I6H3oeo1');
define('UC_SITEID', 'K0h6g901d7w2Y4d718aarcfbRfa3X5c524Z96b1ap3w9Eep9c3l1e0O2k6C3Aen1');
define('UC_MYKEY', '90e6O9V1r7v224N7j88aZcpbFfO305M5t4c9hb9a73W9BeE943j180A2P6C3Sec1');
define('UC_DEBUG', false);
define('UC_PPP', 20);
