<?php

namespace Home\Controller;
use Think\Controller;

class UserController extends Controller {

    public function index(){

        $condition['user'] = I('user');
        $data['money'] = I('money');
        $res = M('member')->where($condition)->save($data);
        var_dump($res);
    }



    public function exp_inject(){
        $user['id'] = $_GET['id'];
        $value = M("member")->where($user)->find();
        var_dump($value);
    }
}

