<?php

namespace Home\Controller;
use Think\Controller;

class UserController extends Controller {

    public function index(){

        $condition['user'] = I('user');
        $data['money'] = I('money');
        $res = M('member')->where($condition)->save($data);
        var_dump($res);
    }
}
/*
namespace Home\Controller;
use Think\Controller;

class UserController extends Controller {

    public function index(){

        $User = M("member");
        $user['id'] = I('id');
        $data['money'] = I('money');
        $data['user'] = I('user');
        $valu = $User->where($user)->save($data);
        var_dump($valu);
    }
}
*/
