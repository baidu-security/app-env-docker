<?php
/**
 *	@package vBUtility
 */

/**
 *	@package vBUtility
 */
class vB_Utility_Password_Exception_SchemeNotSupported extends vB_Utility_Password_Exception {}