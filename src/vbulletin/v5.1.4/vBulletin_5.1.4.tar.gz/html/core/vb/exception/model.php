<?php if (!defined('VB_ENTRY')) die('Access denied.');
/*======================================================================*\
|| #################################################################### ||
|| # vBulletin 5.1.4
|| # ---------------------------------------------------------------- # ||
|| # Copyright �2000-2014 vBulletin Solutions Inc. All Rights Reserved. ||
|| # This file may not be redistributed in whole or significant part. # ||
|| # ---------------- VBULLETIN IS NOT FREE SOFTWARE ---------------- # ||
|| # http://www.vbulletin.com | http://www.vbulletin.com/license.html # ||
|| #################################################################### ||
\*======================================================================*/

/**
 * Model Exception
 * Exception thrown by model classes such as Item and Collection.
 *
 * @package vBulletin
 * @author vBulletin Development Team
 * @version $Revision: 57283 $
 * @since $Date: 2011-12-29 11:46:06 -0800 (Thu, 29 Dec 2011) $
 * @copyright vBulletin Solutions Inc.
 */
class vB_Exception_Model extends vB_Exception
{
}

/*======================================================================*\
|| ####################################################################
|| # SVN: $Revision: 57283 $
|| ####################################################################
\*======================================================================*/