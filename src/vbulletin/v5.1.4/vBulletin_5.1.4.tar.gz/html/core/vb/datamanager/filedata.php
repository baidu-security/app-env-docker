<?php if(!defined('VB_ENTRY')) die('Access denied.');
/*======================================================================*\
|| #################################################################### ||
|| # vBulletin 5.1.4
|| # ---------------------------------------------------------------- # ||
|| # Copyright �2000-2014 vBulletin Solutions Inc. All Rights Reserved. ||
|| # This file may not be redistributed in whole or significant part. # ||
|| # ---------------- VBULLETIN IS NOT FREE SOFTWARE ---------------- # ||
|| # http://www.vbulletin.com | http://www.vbulletin.com/license.html # ||
|| #################################################################### ||
\*======================================================================*/

/**
* Class to do data save/delete operations for just the Filedata table
*
* @package	vBulletin
* @version	$Revision: 35688 $
* @date		$Date: 2010-03-04 21:40:16 -0200 (Thu, 04 Mar 2010) $
*/
class vB_DataManager_Filedata extends vB_DataManager
{

	/**
	 * Array of field names that are bitfields, together with the name of the variable in the registry with the definitions.
	 *
	 * @var	array
	 */
	var $bitfields = array();

	/**
	 * Storage holder
	 *
	 * @var  array   Storage Holder
	 */
	var $lists = array();

	/**
	 * Storage Type
	 *
	 * @var  string
	 */
	var $storage = 'db';

	/**
	* Array of recognized and required fields for attachment inserts
	*
	* @var	array
	*/
	var $validfields = array(
		'filedataid'         => array(vB_Cleaner::TYPE_UINT,     vB_DataManager_Constants::REQ_INCR),
		'userid'             => array(vB_Cleaner::TYPE_UINT,     vB_DataManager_Constants::REQ_YES),
		'dateline'           => array(vB_Cleaner::TYPE_UNIXTIME, vB_DataManager_Constants::REQ_AUTO),
		'filedata'           => array(vB_Cleaner::TYPE_BINARY,   vB_DataManager_Constants::REQ_NO,   vB_DataManager_Constants::VF_METHOD),
		'filesize'           => array(vB_Cleaner::TYPE_UINT,     vB_DataManager_Constants::REQ_YES),
		'filehash'           => array(vB_Cleaner::TYPE_STR,      vB_DataManager_Constants::REQ_YES,  vB_DataManager_Constants::VF_METHOD, 'verify_md5'),
		'extension'          => array(vB_Cleaner::TYPE_STR,      vB_DataManager_Constants::REQ_YES),
		'refcount'           => array(vB_Cleaner::TYPE_UINT,     vB_DataManager_Constants::REQ_NO),
		'width'              => array(vB_Cleaner::TYPE_UINT,     vB_DataManager_Constants::REQ_NO),
		'height'             => array(vB_Cleaner::TYPE_UINT,     vB_DataManager_Constants::REQ_NO),
	);

	/**
	* The main table this class deals with
	*
	* @var	string
	*/
	var $table = 'vBForum:filedata';

	protected $keyField = 'filedataid';

	/**
	* Condition template for update query
	* This is for use with sprintf(). First key is the where clause, further keys are the field names of the data to be used.
	*
	* @var	array
	*/
	var $condition_construct = array('filedataid = %1$d', 'filedataid');

	/**
	* Constructor - checks that the registry object has been passed correctly.
	*
	* @param	vB_Registry	Instance of the vBulletin data registry object - expected to have the database object as one of its $this->db member.
	* @param	integer		One of the ERRTYPE_x constants
	*/
	public function __construct(&$registry, $errtype = vB_DataManager_Constants::ERRTYPE_STANDARD)
	{
		parent::__construct($registry, $errtype);

		$this->storage = vB::getDatastore()->getOption('attachfile') ? 'fs' : 'db';
	}

	// Allows to override attachfile option (used in admincp/attachment.php)
	public function setStorage($attachfile)
	{
		$this->storage = (intval($attachfile)) ? 'fs' : 'db';
	}

	public function pre_delete($doquery = true)
	{
		return parent::pre_delete('filedata', $doquery);
	}

	/**
	 * Set the extension of the filename
	 *
	 * @param	filename
	 *
	 * @return	boolean
	 */
	function verify_filename(&$filename)
	{
		$ext_pos = strrpos($filename, '.');
		if ($ext_pos !== false)
		{
			$extension = substr($filename, $ext_pos + 1);
			// 100 (filename length in DB) - 1 (.) - length of extension
			$filename = substr($filename, 0, min(100 - 1 - strlen($extension), $ext_pos)) . ".$extension";
		}
		else
		{
			$extension = '';
		}

		if ($this->validfields['extension'])
		{
			$this->set('extension', strtolower($extension));
		}
		return true;
	}


	/**
	 * Set the filesize of the thumbnail
	 *
	 * @param	integer	Maximum posts per page
	 *
	 * @return	boolean
	 */
	function verify_thumbnail(&$thumbnail)
	{
		if (strlen($thumbnail) > 0)
		{
			$this->set('thumbnail_filesize', strlen($thumbnail));
		}
		return true;
	}

	/**
	 * Set the filehash/filesize of the file
	 *
	 * @param	integer	Maximum posts per page
	 *
	 * @return	boolean
	 */
	function verify_filedata(&$filedata)
	{
		if (strlen($filedata) > 0)
		{
			$this->set('filehash', md5($filedata));
			$this->set('filesize', strlen($filedata));
		}

		return true;
	}

	/**
	 * Verify that posthash is either md5 or empty
	 * @param	string the md5
	 *
	 * @return	boolean
	 */
	function verify_md5_alt(&$md5)
	{
		return (empty($md5) OR (strlen($md5) == 32 AND preg_match('#^[a-f0-9]{32}$#', $md5)));
	}

	/**
	 * database pre_save method that only applies to subclasses that have filedata fields
	 *
	 * @param	boolean	Do the query?
	 *
	 * @return	boolean	True on success; false if an error occurred
	 */
	function pre_save_filedata($doquery = true)
	{
		if ($this->condition === null)
		{
			if ($this->fetch_field('filehash', 'filedata'))
			{
				$filehash = $this->fetch_field('filehash', 'filedata');
			}
			else if (!empty($this->info['filedata_location']) AND file_exists($this->info['filedata_location']))
			{
				$filehash = md5(file_get_contents($this->info['filedata_location']));
			}
			else if (!empty($this->info['filedata']))
			{
				$filehash = md5($this->info['filedata']);
			}
			else if ($this->fetch_field('filedata', 'filedata'))
			{
				$filehash = md5($this->fetch_field('filedata', 'filedata'));
			}

			// Does filedata already exist?
			if ($filehash AND $fd = $this->registry->db->query_first("
				SELECT filedataid
				FROM " . TABLE_PREFIX . "filedata
				WHERE filehash = '" . $this->registry->db->escape_string($filehash) . "'
			"))
			{
				// file already exists so we are not going to insert a new one
				return $fd['filedataid'];
			}
		}

		if ($this->storage == 'db')
		{
			if (!empty($this->info['filedata_location']) AND file_exists($this->info['filedata_location']))
			{
				$this->set_info('filedata', file_get_contents($this->info['filedata_location']));
			}

			if (!empty($this->info['filedata']))
			{
				$this->setr('filedata', $this->info['filedata']);
			}

			if (!empty($this->info['thumbnail']))
			{
				$this->setr('thumbnail', $this->info['thumbnail']);
			}
		}
		else	// Saving in the filesystem
		{
			// make sure we don't have the binary data set
			// if so move it to an information field
			// benefit of this is that when we "move" files from DB to FS,
			// the filedata fields are not blanked in the database
			// during the update.
			if ($file =& $this->fetch_field('filedata', 'filedata'))
			{
				$this->setr_info('filedata', $file);
				$this->do_unset('filedata', 'filedata');
			}

			if ($thumb =& $this->fetch_field('thumbnail', 'filedata'))
			{
				$this->setr_info('thumbnail', $thumb);
				$this->do_unset('thumbnail', 'filedata');
			}

			if (!empty($this->info['filedata']))
			{
				$this->set('filehash', md5($this->info['filedata']), true, true, 'filedata');
				$this->set('filesize', strlen($this->info['filedata']), true, true, 'filedata');
			}
			else if (!empty($this->info['filedata_location']) AND file_exists($this->info['filedata_location']))
			{
				$this->set('filehash', md5_file($this->info['filedata_location']), true, true, 'filedata');
				$this->set('filesize', filesize($this->info['filedata_location']), true, true, 'filedata');
			}

			if (!empty($this->info['thumbnail']))
			{
				$this->set('thumbnail_filesize', strlen($this->info['thumbnail']), true, true, 'filedata');
			}

			if (!empty($this->info['filedata']) OR !empty($this->info['filedata_location']))
			{
				$path = $this->verify_attachment_path($this->fetch_field('userid', 'filedata'));
				if (!$path)
				{
					$this->error('attachpathfailed');
					return false;
				}

				if (!is_writable($path))
				{
					$this->error('upload_file_system_is_not_writable_path', htmlspecialchars($path));
					return false;
				}
			}
		}

		return true;
	}

	public function delete($doquery = true)
	{
		if (!$this->pre_delete($doquery) OR empty($this->lists['filedataids']))
		{
			return false;
		}

		if (!empty($this->lists['filedataids']))
		{
			$this->registry->db->query_write("
				DELETE FROM " . TABLE_PREFIX . "filedata
				WHERE filedataid IN (" . implode(", ", array_keys($this->lists['filedataids'])) . ")
			");

			$this->registry->db->query_write("
				DELETE FROM " . TABLE_PREFIX . "attachmentcategoryuser
				WHERE filedataid IN (" . implode(", ", array_keys($this->lists['filedataids'])) . ")
			");

			$this->registry->db->query_write("
				DELETE FROM " . TABLE_PREFIX . "filedataresize
				WHERE filedataid IN (" . implode(", ", array_keys($this->lists['filedataids'])) . ")
			");

			if ($this->storage == 'fs')
			{
				require_once(DIR . '/includes/functions_file.php');
				foreach ($this->lists['filedataids'] AS $filedataid => $userid)
				{
					$this->deleteFile(fetch_attachment_path($userid, $filedataid));
					$this->deleteFile(fetch_attachment_path($userid, $filedataid, vB_Api_Filedata::SIZE_THUMB));
					$this->deleteFile(fetch_attachment_path($userid, $filedataid, vB_Api_Filedata::SIZE_ICON));
					$this->deleteFile(fetch_attachment_path($userid, $filedataid, vB_Api_Filedata::SIZE_SMALL));
					$this->deleteFile(fetch_attachment_path($userid, $filedataid, vB_Api_Filedata::SIZE_MEDIUM));
					$this->deleteFile(fetch_attachment_path($userid, $filedataid, vB_Api_Filedata::SIZE_LARGE));
				}
			}

			// unset filedataids so that the post_delete function doesn't bother calculating refcount for the records that we just removed
			unset($this->lists['filedataids']);
		}

		if (!empty($this->lists['attachmentids']))
		{
			$this->registry->db->query_write("
				DELETE FROM " . TABLE_PREFIX . "attachment
				WHERE attachmentid IN (" . implode(", ", $this->lists['attachmentids']) . ")
			");
		}

		$this->post_delete();

		return true;
	}

	/**
	* Saves the data from the object into the specified database tables
	* Overwrites parent
	*
	* @return	mixed	If this was an INSERT query, the INSERT ID is returned
	*/
	function save($doquery = true, $delayed = false, $affected_rows = false, $replace = false, $ignore = false)
	{
		if ($this->has_errors())
		{
			return false;
		}

		if (!$this->pre_save($doquery))
		{
			return false;
		}

		if ($filedataid = $this->pre_save_filedata($doquery))
		{
			if (!$filedataid)
			{
				return false;
			}

			if ($filedataid !== true)
			{
				// this is an insert and file already exists
				$this->attachment['filedataid'] = $this->filedata['filedataid'] = $filedataid;

				$this->post_save_each($doquery);
				$this->post_save_once($doquery);

				// this is an insert and file already exists
				return $filedataid;
			}
		}

		if ($this->condition === null)
		{
			$return = $this->db_insert(TABLE_PREFIX, $this->table, $doquery);
			$this->set('filedataid', $return);
		}
		else
		{
			$return = $this->db_update(TABLE_PREFIX, $this->table, $this->condition, $doquery);
		}

		if ($return AND $this->post_save_each($doquery) AND $this->post_save_once($doquery) AND $this->post_save_each_filedata($doquery))
		{
			return $return;
		}
		else
		{
			return false;
		}
	}
}

/*======================================================================*\
|| ####################################################################
|| # CVS: $RCSfile$ - $Revision: 40911 $
|| ####################################################################
\*======================================================================*/