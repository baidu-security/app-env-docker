<?php
require_once(DIR . '/install/legacy/400a1/vb/datamanager/attachdata.php');
require_once(DIR . '/install/legacy/400a1/vb/datamanager/attachment.php');
require_once(DIR . '/install/legacy/400a1/vb/datamanager/attachmentfiledata.php');
require_once(DIR . '/install/legacy/400a1/packages/vbattach/attach.php');