<?php
	define('DB_HOST', 'localhost');
	define('DB_USER', 'root');
	define('DB_PW', '');
	define('DB_NAME', 'wiki');
	define('DB_CHARSET', 'utf8');
	define('DB_TABLEPRE', 'wiki_');
	define('DB_CONNECT', 0);
	define('WIKI_FOUNDER', 1);
	define('WIKI_CHARSET', 'UTF-8');
	define('WIKI_URL', 'http://{docker_ip_addr}');
?>
