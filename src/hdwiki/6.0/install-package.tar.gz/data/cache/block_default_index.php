<?php
return array (
  0 => 
  array (
    'doc' => 
    array (
      0 => 
      array (
        'id' => '1',
        'theme' => 'default',
        'fun' => 'hotdocs',
        'params' => 'a:2:{s:3:"num";s:0:"";s:5:"style";s:0:"";}',
        'area' => 'ctop1',
        'block' => 'doc',
        'tpl' => 'hotdocs.htm',
      ),
      1 => 
      array (
        'id' => '2',
        'theme' => 'default',
        'fun' => 'wonderdocs',
        'params' => 'a:1:{s:5:"style";s:0:"";}',
        'area' => 'ctop2',
        'block' => 'doc',
        'tpl' => 'wonderdocs.htm',
      ),
      2 => 
      array (
        'id' => '6',
        'theme' => 'default',
        'fun' => 'recentdocs',
        'params' => 'a:2:{s:3:"num";s:0:"";s:5:"style";s:0:"";}',
        'area' => 'dbottomr',
        'block' => 'doc',
        'tpl' => 'recentdocs.htm',
      ),
      3 => 
      array (
        'id' => '10',
        'theme' => 'default',
        'fun' => 'hottags',
        'params' => 'a:1:{s:5:"style";s:0:"";}',
        'area' => 'bottom',
        'block' => 'doc',
        'tpl' => 'hottags.htm',
      ),
      4 => 
      array (
        'id' => '9',
        'theme' => 'default',
        'fun' => 'commenddocs',
        'params' => 'a:1:{s:5:"style";s:0:"";}',
        'area' => 'cbottomr',
        'block' => 'doc',
        'tpl' => 'commenddocs.htm',
      ),
      5 => 
      array (
        'id' => '5',
        'theme' => 'default',
        'fun' => 'cooperatedocs',
        'params' => 'a:1:{s:5:"style";s:0:"";}',
        'area' => 'right',
        'block' => 'doc',
        'tpl' => 'cooperatedocs.htm',
      ),
      6 => 
      array (
        'id' => '17',
        'theme' => 'default',
        'fun' => 'getletterdocs',
        'params' => 'a:1:{s:5:"style";s:0:"";}',
        'area' => 'right',
        'block' => 'doc',
        'tpl' => 'getletterdocs.htm',
      ),
    ),
    'user' => 
    array (
      0 => 
      array (
        'id' => '3',
        'theme' => 'default',
        'fun' => 'login',
        'params' => '',
        'area' => 'right',
        'block' => 'user',
        'tpl' => 'login.htm',
      ),
    ),
    'comment' => 
    array (
      0 => 
      array (
        'id' => '7',
        'theme' => 'default',
        'fun' => 'recentcomment',
        'params' => 'a:1:{s:3:"num";s:0:"";}',
        'area' => 'cbottoml',
        'block' => 'comment',
        'tpl' => 'recentcomment.htm',
      ),
    ),
    'pic' => 
    array (
      0 => 
      array (
        'id' => '8',
        'theme' => 'default',
        'fun' => 'recentpics',
        'params' => 'a:1:{s:3:"num";s:0:"";}',
        'area' => 'cbottomr',
        'block' => 'pic',
        'tpl' => 'recentpics.htm',
      ),
    ),
    'news' => 
    array (
      0 => 
      array (
        'id' => '4',
        'theme' => 'default',
        'fun' => 'recentnews',
        'params' => 'a:1:{s:5:"style";s:0:"";}',
        'area' => 'right',
        'block' => 'news',
        'tpl' => 'recentnews.htm',
      ),
    ),
    'links' => 
    array (
      0 => 
      array (
        'id' => '16',
        'theme' => 'default',
        'fun' => 'friendlinks',
        'params' => 'a:1:{s:5:"style";s:0:"";}',
        'area' => 'bottom',
        'block' => 'links',
        'tpl' => 'friendlinks.htm',
      ),
    ),
  ),
  1 => 
  array (
    'ctop1' => 
    array (
      0 => 
      array (
        'id' => '1',
        'theme' => 'default',
        'fun' => 'hotdocs',
        'params' => 'a:2:{s:3:"num";s:0:"";s:5:"style";s:0:"";}',
        'area' => 'ctop1',
        'block' => 'doc',
        'tpl' => 'hotdocs.htm',
      ),
    ),
    'ctop2' => 
    array (
      0 => 
      array (
        'id' => '2',
        'theme' => 'default',
        'fun' => 'wonderdocs',
        'params' => 'a:1:{s:5:"style";s:0:"";}',
        'area' => 'ctop2',
        'block' => 'doc',
        'tpl' => 'wonderdocs.htm',
      ),
    ),
    'right' => 
    array (
      0 => 
      array (
        'id' => '3',
        'theme' => 'default',
        'fun' => 'login',
        'params' => '',
        'area' => 'right',
        'block' => 'user',
        'tpl' => 'login.htm',
      ),
      1 => 
      array (
        'id' => '4',
        'theme' => 'default',
        'fun' => 'recentnews',
        'params' => 'a:1:{s:5:"style";s:0:"";}',
        'area' => 'right',
        'block' => 'news',
        'tpl' => 'recentnews.htm',
      ),
      2 => 
      array (
        'id' => '5',
        'theme' => 'default',
        'fun' => 'cooperatedocs',
        'params' => 'a:1:{s:5:"style";s:0:"";}',
        'area' => 'right',
        'block' => 'doc',
        'tpl' => 'cooperatedocs.htm',
      ),
      3 => 
      array (
        'id' => '17',
        'theme' => 'default',
        'fun' => 'getletterdocs',
        'params' => 'a:1:{s:5:"style";s:0:"";}',
        'area' => 'right',
        'block' => 'doc',
        'tpl' => 'getletterdocs.htm',
      ),
    ),
    'dbottomr' => 
    array (
      0 => 
      array (
        'id' => '6',
        'theme' => 'default',
        'fun' => 'recentdocs',
        'params' => 'a:2:{s:3:"num";s:0:"";s:5:"style";s:0:"";}',
        'area' => 'dbottomr',
        'block' => 'doc',
        'tpl' => 'recentdocs.htm',
      ),
    ),
    'cbottoml' => 
    array (
      0 => 
      array (
        'id' => '7',
        'theme' => 'default',
        'fun' => 'recentcomment',
        'params' => 'a:1:{s:3:"num";s:0:"";}',
        'area' => 'cbottoml',
        'block' => 'comment',
        'tpl' => 'recentcomment.htm',
      ),
    ),
    'cbottomr' => 
    array (
      0 => 
      array (
        'id' => '8',
        'theme' => 'default',
        'fun' => 'recentpics',
        'params' => 'a:1:{s:3:"num";s:0:"";}',
        'area' => 'cbottomr',
        'block' => 'pic',
        'tpl' => 'recentpics.htm',
      ),
      1 => 
      array (
        'id' => '9',
        'theme' => 'default',
        'fun' => 'commenddocs',
        'params' => 'a:1:{s:5:"style";s:0:"";}',
        'area' => 'cbottomr',
        'block' => 'doc',
        'tpl' => 'commenddocs.htm',
      ),
    ),
    'bottom' => 
    array (
      0 => 
      array (
        'id' => '10',
        'theme' => 'default',
        'fun' => 'hottags',
        'params' => 'a:1:{s:5:"style";s:0:"";}',
        'area' => 'bottom',
        'block' => 'doc',
        'tpl' => 'hottags.htm',
      ),
      1 => 
      array (
        'id' => '16',
        'theme' => 'default',
        'fun' => 'friendlinks',
        'params' => 'a:1:{s:5:"style";s:0:"";}',
        'area' => 'bottom',
        'block' => 'links',
        'tpl' => 'friendlinks.htm',
      ),
    ),
  ),
);
?>