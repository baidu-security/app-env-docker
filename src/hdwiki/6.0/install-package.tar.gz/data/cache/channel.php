<?php
return array (
  0 => 
  array (
    'id' => '1',
    'name' => '首页',
    'url' => 'http://172.17.0.2',
    'displayorder' => '0',
    'available' => '1',
    'position' => '2',
  ),
  1 => 
  array (
    'id' => '2',
    'name' => '百科分类',
    'url' => 'http://172.17.0.2/index.php?category',
    'displayorder' => '1',
    'available' => '1',
    'position' => '2',
  ),
  2 => 
  array (
    'id' => '3',
    'name' => '排行榜',
    'url' => 'http://172.17.0.2/index.php?list',
    'displayorder' => '2',
    'available' => '1',
    'position' => '2',
  ),
  3 => 
  array (
    'id' => '4',
    'name' => '图片百科',
    'url' => 'http://172.17.0.2/index.php?pic-piclist-2',
    'displayorder' => '3',
    'available' => '1',
    'position' => '2',
  ),
  4 => 
  array (
    'id' => '5',
    'name' => '礼品商店',
    'url' => 'http://172.17.0.2/index.php?gift',
    'displayorder' => '4',
    'available' => '1',
    'position' => '2',
  ),
);
?>