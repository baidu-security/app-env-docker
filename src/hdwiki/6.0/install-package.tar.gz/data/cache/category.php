<?php
return array (
  0 => 
  array (
    'cid' => '1',
    'pid' => '3',
    'name' => 'HDWIKI',
    'displayorder' => '0',
    'docs' => '18',
    'image' => '',
    'navigation' => 'a:2:{i:0;a:2:{s:3:"cid";i:3;s:4:"name";s:12:"帮助文档";}i:1;a:2:{s:3:"cid";s:1:"1";s:4:"name";s:6:"HDWIKI";}}',
    'description' => '',
  ),
  1 => 
  array (
    'cid' => '10',
    'pid' => '6',
    'name' => '词条产品相关',
    'displayorder' => '0',
    'docs' => '8',
    'image' => '',
    'navigation' => 'a:3:{i:0;a:2:{s:3:"cid";i:3;s:4:"name";s:12:"帮助文档";}i:1;a:2:{s:3:"cid";s:1:"6";s:4:"name";s:12:"词条相关";}i:2;a:2:{s:3:"cid";s:2:"10";s:4:"name";s:18:"词条产品相关";}}',
    'description' => '',
  ),
  2 => 
  array (
    'cid' => '4',
    'pid' => '3',
    'name' => 'wik相关',
    'displayorder' => '1',
    'docs' => '3',
    'image' => '',
    'navigation' => 'a:2:{i:0;a:2:{s:3:"cid";i:3;s:4:"name";s:12:"帮助文档";}i:1;a:2:{s:3:"cid";s:1:"4";s:4:"name";s:9:"wik相关";}}',
    'description' => '',
  ),
  3 => 
  array (
    'cid' => '11',
    'pid' => '6',
    'name' => '词条命名规范',
    'displayorder' => '1',
    'docs' => '2',
    'image' => '',
    'navigation' => 'a:3:{i:0;a:2:{s:3:"cid";i:3;s:4:"name";s:12:"帮助文档";}i:1;a:2:{s:3:"cid";s:1:"6";s:4:"name";s:12:"词条相关";}i:2;a:2:{s:3:"cid";s:2:"11";s:4:"name";s:18:"词条命名规范";}}',
    'description' => '',
  ),
  4 => 
  array (
    'cid' => '2',
    'pid' => '3',
    'name' => '互动百科',
    'displayorder' => '2',
    'docs' => '1',
    'image' => '',
    'navigation' => 'a:2:{i:0;a:2:{s:3:"cid";i:3;s:4:"name";s:12:"帮助文档";}i:1;a:2:{s:3:"cid";s:1:"2";s:4:"name";s:12:"互动百科";}}',
    'description' => '',
  ),
  5 => 
  array (
    'cid' => '3',
    'pid' => '0',
    'name' => '帮助文档',
    'displayorder' => '2',
    'docs' => '0',
    'image' => '',
    'navigation' => 'a:1:{i:0;a:2:{s:3:"cid";i:3;s:4:"name";s:12:"帮助文档";}}',
    'description' => '',
  ),
  6 => 
  array (
    'cid' => '12',
    'pid' => '6',
    'name' => '词条内容编写规范',
    'displayorder' => '2',
    'docs' => '12',
    'image' => '',
    'navigation' => 'a:3:{i:0;a:2:{s:3:"cid";i:3;s:4:"name";s:12:"帮助文档";}i:1;a:2:{s:3:"cid";s:1:"6";s:4:"name";s:12:"词条相关";}i:2;a:2:{s:3:"cid";s:2:"12";s:4:"name";s:24:"词条内容编写规范";}}',
    'description' => '',
  ),
  7 => 
  array (
    'cid' => '5',
    'pid' => '3',
    'name' => '帐号相关',
    'displayorder' => '3',
    'docs' => '4',
    'image' => '',
    'navigation' => 'a:2:{i:0;a:2:{s:3:"cid";i:3;s:4:"name";s:12:"帮助文档";}i:1;a:2:{s:3:"cid";s:1:"5";s:4:"name";s:12:"帐号相关";}}',
    'description' => '',
  ),
  8 => 
  array (
    'cid' => '6',
    'pid' => '3',
    'name' => '词条相关',
    'displayorder' => '4',
    'docs' => '0',
    'image' => '',
    'navigation' => 'a:2:{i:0;a:2:{s:3:"cid";i:3;s:4:"name";s:12:"帮助文档";}i:1;a:2:{s:3:"cid";s:1:"6";s:4:"name";s:12:"词条相关";}}',
    'description' => '',
  ),
  9 => 
  array (
    'cid' => '7',
    'pid' => '3',
    'name' => '分类相关',
    'displayorder' => '5',
    'docs' => '0',
    'image' => '',
    'navigation' => 'a:2:{i:0;a:2:{s:3:"cid";i:3;s:4:"name";s:12:"帮助文档";}i:1;a:2:{s:3:"cid";s:1:"7";s:4:"name";s:12:"分类相关";}}',
    'description' => '',
  ),
  10 => 
  array (
    'cid' => '8',
    'pid' => '3',
    'name' => '投诉建议',
    'displayorder' => '6',
    'docs' => '0',
    'image' => '',
    'navigation' => 'a:2:{i:0;a:2:{s:3:"cid";i:3;s:4:"name";s:12:"帮助文档";}i:1;a:2:{s:3:"cid";s:1:"8";s:4:"name";s:12:"投诉建议";}}',
    'description' => '',
  ),
  11 => 
  array (
    'cid' => '9',
    'pid' => '3',
    'name' => '用户相关',
    'displayorder' => '7',
    'docs' => '0',
    'image' => '',
    'navigation' => 'a:2:{i:0;a:2:{s:3:"cid";i:3;s:4:"name";s:12:"帮助文档";}i:1;a:2:{s:3:"cid";s:1:"9";s:4:"name";s:12:"用户相关";}}',
    'description' => '',
  ),
);
?>