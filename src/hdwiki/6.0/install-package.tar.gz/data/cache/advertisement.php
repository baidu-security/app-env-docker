<?php
return array (
  0 => 
  array (
    'advid' => '1',
    'available' => '1',
    'type' => '0',
    'title' => '页头通栏广告',
    'targets' => 'all',
    'position' => '0',
    'parameters' => 'a:4:{s:5:"style";s:4:"code";s:4:"html";s:237:"<div class="wrap" style="background:url(style/default/home-banner1.png) no-repeat center top;height:285px;text-align:center;"><a href="http://kaiyuan.baike.com/" style="display: block; width:100%; height: 100%" target="_blank"></a></div>";s:8:"position";s:0:"";s:12:"displayorder";i:0;}',
    'code' => '<div class="wrap" style="background:url(style/default/home-banner1.png) no-repeat center top;height:285px;text-align:center;"><a href="http://kaiyuan.baike.com/" style="display: block; width:100%; height: 100%" target="_blank"></a></div>',
    'starttime' => '0',
    'endtime' => '0',
  ),
  1 => 
  array (
    'advid' => '2',
    'available' => '1',
    'type' => '2',
    'title' => '首页栏目间广告',
    'targets' => '',
    'position' => '0',
    'parameters' => 'a:9:{s:5:"style";s:5:"image";s:3:"url";s:66:"style/default/banner.jpg";s:4:"link";s:57:"http://so.baike.com/so/wikiad.html?q=%E7%A7%9F%E6%88%BF ";s:5:"width";s:3:"710";s:6:"height";s:2:"80";s:3:"alt";s:42:"租房子，找工作，尽在生活搜索";s:4:"html";s:250:"<a href="http://so.baike.com/so/wikiad.html?q=%E7%A7%9F%E6%88%BF " target="_blank"><img src="install/testdata/ad_710.jpg" border="0"></a>";s:8:"position";s:0:"";s:12:"displayorder";i:0;}',
    'code' => '<a href="http://so.baike.com/so/wikiad.html?q=%E7%A7%9F%E6%88%BF " target="_blank"><img src="style/default/banner.jpg" alt="租房子，找工作，尽在生活搜索" border="0"></a>',
    'starttime' => '0',
    'endtime' => '0',
  ),
  2 => 
  array (
    'advid' => '3',
    'available' => '1',
    'type' => '4',
    'title' => '词条页右侧广告',
    'targets' => 'all',
    'position' => '1',
    'parameters' => 'a:9:{s:5:"style";s:5:"image";s:3:"url";s:66:"install/testdata/ad_230.jpg";s:4:"link";s:66:"http://so.baike.com/so/wikiad.html?q=%E6%89%BE%E5%B7%A5%E4%BD%9C ";s:5:"width";s:3:"230";s:6:"height";s:3:"230";s:3:"alt";s:42:"租房子，找工作，尽在生活搜索";s:4:"html";s:260:"<a href="http://so.baike.com/so/wikiad.html?q=%E6%89%BE%E5%B7%A5%E4%BD%9C " target="_blank"><img src="install/testdata/ad_230.jpg" height="230" width="230" alt="租房子，找工作，尽在生活搜索" border="0"></a>";s:8:"position";s:1:"1";s:12:"displayorder";i:0;}',
    'code' => '<a href="http://so.baike.com/so/wikiad.html?q=%E6%89%BE%E5%B7%A5%E4%BD%9C " target="_blank"><img src="install/testdata/ad_230.jpg" height="230" width="230" alt="租房子，找工作，尽在生活搜索" border="0"></a>',
    'starttime' => '0',
    'endtime' => '0',
  ),
);
?>