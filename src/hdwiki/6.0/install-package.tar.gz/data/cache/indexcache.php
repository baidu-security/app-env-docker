<?php
return array (
  'commenddocs' => 
  array (
    0 => 
    array (
      'did' => '46',
      'title' => '姓氏类规范',
      'tag' => '',
      'summary' => '姓氏类词条（含中文和外文姓氏），包含但不限于以下方面： 1、起源 2、发展演变 3、分布 4、郡望堂号 5、字辈 6、族谱 7、×氏名人 姓氏类词条（含中文和外文姓氏）内容需注意以下几方面： 1、与单字、×氏的区别 如',
      'image' => 'style/default/recommend_l.jpg',
      'time' => '08-02 10:33',
      'displayorder' => '0',
      'type' => '1',
      'shorttitle' => '姓氏类规范',
      'rawtitle' => '姓氏类规范',
      'simage' => 'style/default/s_f_recommend_l.jpg',
    ),
    1 => 
    array (
      'did' => '45',
      'title' => '人物类规范',
      'tag' => '',
      'summary' => '人物类词条编写规范1、内容要简明扼要，逻辑清晰 从简介、生平、成绩、荣誉、作品、重点事件、评价等方面简介。如果每个目录间内容有交叉或重复，要进行整理后再发布，同样内容不要重复出现。不存在的方面，不要生搬',
      'image' => 'style/default/recommend_l.jpg',
      'time' => '08-02 10:33',
      'displayorder' => '0',
      'type' => '1',
      'shorttitle' => '人物类规范',
      'rawtitle' => '人物类规范',
      'simage' => 'style/default/s_f_recommend_l.jpg',
    ),
    2 => 
    array (
      'did' => '44',
      'title' => '汽车类规范',
      'tag' => '',
      'summary' => '汽车类词条编写规范： 1、内容要准确、详细的参数表，最好是数据化的，方便读者和用户搜索。 2、客观中立的用语，避免大篇幅照搬软文、广告或宣传稿。 3、大类、大系列词条注意内容主次分明，重点放在大系列、大类整',
      'image' => 'style/default/recommend_l.jpg',
      'time' => '08-02 10:33',
      'displayorder' => '0',
      'type' => '1',
      'shorttitle' => '汽车类规范',
      'rawtitle' => '汽车类规范',
      'simage' => 'style/default/s_f_recommend_l.jpg',
    ),
    3 => 
    array (
      'did' => '43',
      'title' => '民族、种族类规范',
      'tag' => '',
      'summary' => '民族、种族类词条内容可以包括但不限于以下方面 1、概况：如人口数量、分布地区等基本情况 2、起源及演变 3、信仰 4、饮食 5、服装 6、婚葬 7、传统节日 8、自治地区 9、民系 10、姓氏 11、知名人士 民族、种族类词条',
      'image' => 'style/default/recommend_l.jpg',
      'time' => '08-02 10:33',
      'displayorder' => '0',
      'type' => '1',
      'shorttitle' => '民族、种族类规范...',
      'rawtitle' => '民族、种族类规范',
      'simage' => 'style/default/s_f_recommend_l.jpg',
    ),
    4 => 
    array (
      'did' => '42',
      'title' => '经管、法理类规范',
      'tag' => '',
      'summary' => '经济、管理、法律理论类词条写易犯的错误： 
1、“文不对题” 文不对题，一般有两种情况： 一是词条内容与词条名称完全不符，如在词条边际效益中添加了效益的概念。 二是，词条内容不能全面说明词条名称，如在词条资',
      'image' => 'style/default/recommend_l.jpg',
      'time' => '08-02 10:33',
      'displayorder' => '0',
      'type' => '1',
      'shorttitle' => '经管、法理类规范...',
      'rawtitle' => '经管、法理类规范',
      'simage' => 'style/default/s_f_recommend_l.jpg',
    ),
    5 => 
    array (
      'did' => '41',
      'title' => '会展类规范',
      'tag' => '',
      'summary' => '会展类词条编写总体要求
1、内容不宜过长，简明精炼即可 2、目录逻辑要清晰、顺畅 3、避免新闻性语体 4、图片、分类、相关词条、参考资料、内链等参照高分词条标准 会展类词条内容可以包括但不限于以下方面 1、会展',
      'image' => 'style/default/recommend_l.jpg',
      'time' => '08-02 10:33',
      'displayorder' => '0',
      'type' => '1',
      'shorttitle' => '会展类规范',
      'rawtitle' => '会展类规范',
      'simage' => 'style/default/s_f_recommend_l.jpg',
    ),
    6 => 
    array (
      'did' => '40',
      'title' => '地名类规范',
      'tag' => '',
      'summary' => '地名类词条编写规范1、内容不求多，要求精，简单明确，可读性强的词条才是高分高质量的词条。 2、要注意内容逻辑性，要依照历史、地理、气候、环境、资源、经济、交通、行政区划、旅游、政治、文化、教育的顺序，从以',
      'image' => 'style/default/recommend_l.jpg',
      'time' => '08-02 10:33',
      'displayorder' => '0',
      'type' => '1',
      'shorttitle' => '地名类规范',
      'rawtitle' => '地名类规范',
      'simage' => 'style/default/s_f_recommend_l.jpg',
    ),
    7 => 
    array (
      'did' => '39',
      'title' => '内容编写规范总则',
      'tag' => '',
      'summary' => '词条内容有三个基本原则
1、内容需客观中立 2、内容非个人原创 3、内容需有据可查 
以下几类内容不适合作为百科词条被收录
1、不经筛选的资料：不经筛选、识别的资料，请勿直接复制、拷贝入互动百科。 2、个人理念',
      'image' => 'style/default/recommend_l.jpg',
      'time' => '08-02 10:33',
      'displayorder' => '0',
      'type' => '1',
      'shorttitle' => '内容编写规范总则...',
      'rawtitle' => '内容编写规范总则',
      'simage' => 'style/default/s_f_recommend_l.jpg',
    ),
  ),
  'hotdocs' => 
  array (
    0 => 
    array (
      'did' => '37',
      'title' => '词条名称总则',
      'tag' => '',
      'summary' => '词条命名原则 1、尽量使用中文 词条名称应尽量使用中文命名，并将',
      'image' => 'style/default/recommend_l.jpg',
      'time' => '08-02 10:33',
      'displayorder' => '0',
      'type' => '2',
      'shorttitle' => '词条名称总则',
      'rawtitle' => '词条名称总则',
      'simage' => 'style/default/s_f_recommend_l.jpg',
    ),
    1 => 
    array (
      'did' => '35',
      'title' => '同义词',
      'tag' => '',
      'summary' => '同义词什么叫同义词？
同义词，是表达的意义相同但是名称不同',
      'image' => 'uploads/201007/s_f_1280483039ysMVbk9b_s.gif',
      'time' => '08-02 10:33',
      'displayorder' => '0',
      'type' => '2',
      'shorttitle' => '同义词',
      'rawtitle' => '同义词',
      'simage' => 'uploads/201007/s_f_s_f_1280483039ysMVbk9b_s.gif',
    ),
    2 => 
    array (
      'did' => '36',
      'title' => '相关词条',
      'tag' => '',
      'summary' => '相关词条
什么是相关词条？ 相关词条就是与一个词条相关的其他',
      'image' => 'uploads/201007/s_f_1280484381eiJRbLHZ_s.gif',
      'time' => '08-02 10:33',
      'displayorder' => '0',
      'type' => '2',
      'shorttitle' => '相关词条',
      'rawtitle' => '相关词条',
      'simage' => 'uploads/201007/s_f_s_f_1280484381eiJRbLHZ_s.gif',
    ),
  ),
  'hotdocounts' => '3',
  'fistwonderdoc' => 
  array (
    'did' => '58',
    'title' => 'HDwiki6.0',
    'tag' => '',
    'summary' => '6.0新版本特性 为报答广大用户对HDwiki的支持，我们为广大wiki爱好者带来了全新的HDwiki6.0——  新增功能：&nb',
    'image' => 'uploads/201612/1482477431DFVigSgj_s.png',
    'time' => '12-23 15:16',
    'displayorder' => '0',
    'type' => '3',
    'shorttitle' => 'HDwiki6.0',
    'rawtitle' => 'HDwiki6.0',
    'simage' => 'uploads/201612/s_f_1482477431DFVigSgj_s.png',
  ),
  'wonderdocs' => 
  array (
    0 => 
    array (
      'did' => '38',
      'title' => '命名规范',
      'tag' => '',
      'summary' => '地名类词条命名规范 
1、中国行政区划的命名规范 按行政区划名，中国省市县，须加上省、市、县等全称，如固原市、银川市。对于区、 县或村镇，一般使用全名，不加上一级行',
      'image' => 'style/default/recommend.jpg',
      'time' => '08-02 10:33',
      'displayorder' => '0',
      'type' => '3',
      'shorttitle' => '命名规范',
      'rawtitle' => '命名规范',
      'simage' => 'style/default/s_f_recommend.jpg',
    ),
    1 => 
    array (
      'did' => '33',
      'title' => '历史版本',
      'tag' => '',
      'summary' => '什么是历史版本？ 每个编辑者编辑词条后，并不是直接覆盖词条原有内容，而是将原有内容保存，将新增或修改的内容保存并于原因内容合并保存为新版本。这样，每一次编辑都会产',
      'image' => 'uploads/201007/s_f_1280480111x5gMoLRz_s.jpg',
      'time' => '08-02 10:33',
      'displayorder' => '0',
      'type' => '3',
      'shorttitle' => '历史版本',
      'rawtitle' => '历史版本',
      'simage' => 'uploads/201007/s_f_s_f_1280480111x5gMoLRz_s.jpg',
    ),
    2 => 
    array (
      'did' => '34',
      'title' => '协作者',
      'tag' => '',
      'summary' => '什么是协作者？ 词条的协作者是参与该词条编辑的所有用户。 什么是最新协作者？ 最新协作者是指最近一个参与该词条编辑的用户。在词条正文页右侧，可以查看到该词条当前的最',
      'image' => 'uploads/201007/s_f_1280481631dwnSN6dQ_s.jpg',
      'time' => '08-02 10:33',
      'displayorder' => '0',
      'type' => '3',
      'shorttitle' => '协作者',
      'rawtitle' => '协作者',
      'simage' => 'uploads/201007/s_f_s_f_1280481631dwnSN6dQ_s.jpg',
    ),
    3 => 
    array (
      'did' => '31',
      'title' => '编辑器',
      'tag' => '',
      'summary' => '什么是编辑器？ 互动百科编辑器，是互动百科自主研发WIKI词条编辑工具，提供给广大站长使用。每个词条编写都是使用编辑器来完成。 编辑器有哪些功能？ 互动百科编辑器可以',
      'image' => 'style/default/recommend.jpg',
      'time' => '08-02 10:33',
      'displayorder' => '0',
      'type' => '3',
      'shorttitle' => '编辑器',
      'rawtitle' => '编辑器',
      'simage' => 'style/default/s_f_recommend.jpg',
    ),
    4 => 
    array (
      'did' => '26',
      'title' => '信用和积分',
      'tag' => '',
      'summary' => '什么是信用？ 信用是本站对于热衷于百科编辑，并能贡献优质内容的用户的奖励。编辑百科词条并贡献优质内容都有可能获得信用。 信用由经验丰富的站务人工评审后可以获得，通',
      'image' => 'style/default/recommend.jpg',
      'time' => '08-02 10:33',
      'displayorder' => '0',
      'type' => '3',
      'shorttitle' => '信用和积分',
      'rawtitle' => '信用和积分',
      'simage' => 'style/default/s_f_recommend.jpg',
    ),
  ),
  'piclist' => 
  array (
    0 => 
    array (
      'id' => '41',
      'did' => '30',
      'time' => '12-23 15:40',
      'filename' => '插入表格.png',
      'description' => '插入表格',
      'filetype' => 'png',
      'filesize' => '14542',
      'attachment' => 'uploads/201612/14824788446TqN1ZRx_140.png',
      'downloads' => '0',
      'coindown' => '0',
      'isimage' => '1',
      'uid' => '1',
      'state' => '0',
      'focus' => '1',
      'title' => '创建/协作',
      'rawtitle' => '创建/协作',
      'sizeinfo' => '394*340 - 14k - png',
      'subdescription' => '插入表格',
      'attachment_normal' => 'uploads/201612/14824788446TqN1ZRx.png',
      'summary' => NULL,
    ),
    1 => 
    array (
      'id' => '40',
      'did' => '30',
      'time' => '12-23 15:40',
      'filename' => '插入图片.png',
      'description' => '上传图片',
      'filetype' => 'png',
      'filesize' => '28100',
      'attachment' => 'uploads/201612/14824788132U3rdPKf_140.png',
      'downloads' => '0',
      'coindown' => '0',
      'isimage' => '1',
      'uid' => '1',
      'state' => '0',
      'focus' => '1',
      'title' => '创建/协作',
      'rawtitle' => '创建/协作',
      'sizeinfo' => '344*541 - 27k - png',
      'subdescription' => '上传图片',
      'attachment_normal' => 'uploads/201612/14824788132U3rdPKf.png',
      'summary' => NULL,
    ),
    2 => 
    array (
      'id' => '39',
      'did' => '30',
      'time' => '12-23 15:39',
      'filename' => '内链.png',
      'description' => '添加内链',
      'filetype' => 'png',
      'filesize' => '53083',
      'attachment' => 'uploads/201612/1482478788Gn8qCokn_140.png',
      'downloads' => '0',
      'coindown' => '0',
      'isimage' => '1',
      'uid' => '1',
      'state' => '0',
      'focus' => '1',
      'title' => '创建/协作',
      'rawtitle' => '创建/协作',
      'sizeinfo' => '883*294 - 52k - png',
      'subdescription' => '添加内链',
      'attachment_normal' => 'uploads/201612/1482478788Gn8qCokn.png',
      'summary' => NULL,
    ),
    3 => 
    array (
      'id' => '38',
      'did' => '30',
      'time' => '12-23 15:39',
      'filename' => '目录展示效果.png',
      'description' => '目录展示效果',
      'filetype' => 'png',
      'filesize' => '28408',
      'attachment' => 'uploads/201612/1482478773LGypHWwC_140.png',
      'downloads' => '0',
      'coindown' => '0',
      'isimage' => '1',
      'uid' => '1',
      'state' => '0',
      'focus' => '1',
      'title' => '创建/协作',
      'rawtitle' => '创建/协作',
      'sizeinfo' => '296*440 - 28k - png',
      'subdescription' => '目录展示效果',
      'attachment_normal' => 'uploads/201612/1482478773LGypHWwC.png',
      'summary' => NULL,
    ),
    4 => 
    array (
      'id' => '37',
      'did' => '30',
      'time' => '12-23 15:39',
      'filename' => '设置目录.png',
      'description' => '设置目录',
      'filetype' => 'png',
      'filesize' => '25103',
      'attachment' => 'uploads/201612/1482478750CCuUTIBW_140.png',
      'downloads' => '0',
      'coindown' => '0',
      'isimage' => '1',
      'uid' => '1',
      'state' => '0',
      'focus' => '1',
      'title' => '创建/协作',
      'rawtitle' => '创建/协作',
      'sizeinfo' => '1098*103 - 25k - png',
      'subdescription' => '设置目录',
      'attachment_normal' => 'uploads/201612/1482478750CCuUTIBW.png',
      'summary' => NULL,
    ),
    5 => 
    array (
      'id' => '36',
      'did' => '34',
      'time' => '12-23 15:38',
      'filename' => '词条协作.png',
      'description' => '协作者',
      'filetype' => 'png',
      'filesize' => '27535',
      'attachment' => 'uploads/201612/1482478686dj6P24lB_140.png',
      'downloads' => '0',
      'coindown' => '0',
      'isimage' => '1',
      'uid' => '1',
      'state' => '0',
      'focus' => '1',
      'title' => '协作者',
      'rawtitle' => '协作者',
      'sizeinfo' => '286*361 - 27k - png',
      'subdescription' => '协作者',
      'attachment_normal' => 'uploads/201612/1482478686dj6P24lB.png',
      'summary' => NULL,
    ),
    6 => 
    array (
      'id' => '35',
      'did' => '33',
      'time' => '12-23 15:37',
      'filename' => '查看历史版本.png',
      'description' => '查看历史版本',
      'filetype' => 'png',
      'filesize' => '19474',
      'attachment' => 'uploads/201612/14824786397u0dU44N_140.png',
      'downloads' => '0',
      'coindown' => '0',
      'isimage' => '1',
      'uid' => '1',
      'state' => '0',
      'focus' => '1',
      'title' => '历史版本',
      'rawtitle' => '历史版本',
      'sizeinfo' => '287*276 - 19k - png',
      'subdescription' => '查看历史版本',
      'attachment_normal' => 'uploads/201612/14824786397u0dU44N.png',
      'summary' => NULL,
    ),
    7 => 
    array (
      'id' => '34',
      'did' => '24',
      'time' => '12-23 15:32',
      'filename' => '注册与登录.png',
      'description' => '注册与登录',
      'filetype' => 'png',
      'filesize' => '96662',
      'attachment' => 'uploads/201612/1482478379QfzdcM6m_140.png',
      'downloads' => '0',
      'coindown' => '0',
      'isimage' => '1',
      'uid' => '1',
      'state' => '0',
      'focus' => '1',
      'title' => '注册/登录',
      'rawtitle' => '注册/登录',
      'sizeinfo' => '951*527 - 94k - png',
      'subdescription' => '注册与登录',
      'attachment_normal' => 'uploads/201612/1482478379QfzdcM6m.png',
      'summary' => NULL,
    ),
  ),
  'cooperatedocs' => 
  array (
    0 => 
    array (
      'shorttitle' => '东北虎',
      'title' => '东北虎',
    ),
    1 => 
    array (
      'shorttitle' => '蝙蝠',
      'title' => '蝙蝠',
    ),
    2 => 
    array (
      'shorttitle' => '大耳蝠',
      'title' => '大耳蝠',
    ),
    3 => 
    array (
      'shorttitle' => '维基尼亚鹿',
      'title' => '维基尼亚鹿',
    ),
    4 => 
    array (
      'shorttitle' => '裸鼹鼠',
      'title' => '裸鼹鼠',
    ),
    5 => 
    array (
      'shorttitle' => '草原犬鼠',
      'title' => '草原犬鼠',
    ),
    6 => 
    array (
      'shorttitle' => '指狐猴',
      'title' => '指狐猴',
    ),
    7 => 
    array (
      'shorttitle' => '树獭',
      'title' => '树獭',
    ),
    8 => 
    array (
      'shorttitle' => '王企鹅',
      'title' => '王企鹅',
    ),
  ),
  'recentupdatelist' => 
  array (
    0 => 
    array (
      'did' => '30',
      'cid' => '0',
      'letter' => 'c',
      'title' => '创建/协作',
      'tag' => '',
      'summary' => '如何创建词条？ 首先，您需要确认将要创建的词条符合“互动百科词条名称规范”。 然后，你可以通过以下方法创建词条： 搜索您要创建的百科词条，如果您搜索的词条未创建，会提示您进入该词条的创建页面。创建词条时',
      'content' => '<div class="hd"  wiki_tmml="">如何创建词条？ </div><p>首先，您需要确认将要创建的词条符合“互动百科词条名称规范”。 <br />然后，你可以通过以下方法创建词条： <br /><br />搜索您要创建的百科词条，如果您搜索的词条未创建，会提示您进入该词条的创建页面。创建词条时，还可以为词条添加相应的开放分类。 <br /><br /></p><div class="hd"  wiki_tmml="">什么是规范的词条名称？ </div><p>互动百科词条名称的基本规范为：<br /><br /><strong>1、词条名称必须是陈述性词语，不可以在词条前后加修饰性词语。</strong><br /><br />正确示例：故宫、刘德华、大熊猫 <br />错误示例：毛泽东主席、白居易（公元772年—公元846年）、迈克尔•乔丹(Michael Jordan) 、伟大的中国共产党、偶像周杰伦。 <br /><br /><strong>2、词条名称不可以是一个短语或是句子、讨论话题、新闻类文章名称等。</strong><br /><br />错误示例：例如“网站访问量上不去的19个因素” <br /><br /><strong>3、词条名称不可以含有特殊符号和空格。</strong><br /><br />错误示例：％，＊，～，＞，＃等。 <br /><br /><strong>4、词条名称中不可以含有错别字。</strong><br /><br />错误示例：马领薯。 <br /><br /></p><div class="hd"  wiki_tmml="">如何协作词条？ </div><p>互动百科的所有词条都可编辑，在词条正文页点击 “编辑词条”按钮，即可对词条进行编辑。此外，还可对词条进行分段编辑，点击段落右上方的“编辑本段”按钮，即可对该段落进行编辑。 <br /><br /></p><div class="hd"  wiki_tmml="">什么是目录？如何添加目录？ </div><p><br />互动百科的目录类似于文章中的段落标题，是组织词条内容的重要工具。目录还有索引的功能，浏览者通过点击目录可以快速到达并浏览该段内容。 <br /><br />在词条编辑页面，用鼠标选中要成为目录标题的文字，然后点击“添加目录”按钮，文章就会自动生成一个目录。如下图所示： 
</p><div class="img img_r" style="width:300px;" id="wrap-img-0"><a title="设置目录" href="uploads/201612/1482478750CCuUTIBW.png" target="_blank"><img title="设置目录" alt="设置目录" src="uploads/201612/1482478750CCuUTIBW_s.png" id="img-0" /></a><strong>设置目录</strong></div><p><br /></p><p><br /><br /><br /><br /><br /><br />为了简明扼要，建议每个目录字数在6个字以内。 <br />目录分为两级，一级目录以下可以设置多个二级目录，两级目录会同时显示在页面索引中。 <br />当编辑完词条，点击“发布”按钮后，编辑器就会在词条正文中自动生成一个目录。目录前半部分为词条名称，后半部分为您添加的目录。 <br />目录生成后，在词条正文页，目录数如超过5个，多出部分将自动隐藏，点击“显示全部”，即可看到完整目录。如下图所示： 
</p><div class="img img_l" style="width:202px;" id="wrap-img-1"><a title="目录展示效果" href="uploads/201612/1482478773LGypHWwC.png" target="_blank"><img title="目录展示效果" alt="目录展示效果" src="uploads/201612/1482478773LGypHWwC_s.png" id="img-1" /></a><strong>目录展示效果</strong></div><p><br /></p><p><br /><br /><br /><br /><br /><br /><br /><br />&nbsp;</p><p>&nbsp;</p><p>小贴士：添加两级目录的快捷键分别是Ctrl+1与ctrl+2。 </p><div class="hd"  wiki_tmml="">什么是内链？ </div><p>内链，全称内部链接。当一个词条正文中包含有其他相关或者热门词条时，用户在点击这些词条的内部链接后将跳转到相应的词条中，方便了用户的扩展阅读。在词条中添加内部链接，可以加强词条与词条之间的关联性，这是百科编辑中非常重要的一个环节，也是衡量百科编辑水平高低的重要参考。 <br /><br />在词条编辑页面，用鼠标选中要添加内部链接的文字，然后点击“内链”按钮，文字上就会添加上内部链接。如下图所示： </p><div class="img img_l" style="width:300px;" id="wrap-img-2"><a title="添加内链" href="uploads/201612/1482478788Gn8qCokn.png" target="_blank"><img title="添加内链" alt="添加内链" src="uploads/201612/1482478788Gn8qCokn_s.png" id="img-2" /></a><strong>添加内链</strong></div><p><br /></p><p><br /><br /><br /><br /><br />小贴士：插入内部链接的快捷方式是Alt+Q&nbsp;<br /></p><p>内部链接的注意事项： <br />a、词条本身不用刷链接，示例：“月食”这个词条下，不要将 “月食”刷成内部链接。 <br />b、内部链接的规范与词条名称规范相同，请参见词条名称基本规范。 <br />c、内部链接应考虑词条准确性、完整性，如“某某毕业于北京大学”，内部链接应该选“北京大学”，而不是选“北京”。 <br /></p><div class="hd"  wiki_tmml="">如何插入图片？ </div><p>在词条中，插入合理的图片，不仅能让词条版面更美观，而且能帮助读者更准确地理解词条的内容。 <br />在词条的编辑页面中，首先选择好插入图片的位置然后点击“插入图片”。 <br />在弹出的图片选择页（如下图）上，点击“浏览”选择要上传的图片。 <br /></p><div class="img img_l" style="width:191px;" id="wrap-img-3"><a title="上传图片" href="uploads/201612/14824788132U3rdPKf.png" target="_blank"><img title="上传图片" alt="上传图片" src="uploads/201612/14824788132U3rdPKf_s.png" id="img-3" /></a><strong>上传图片</strong></div><p><br /></p><p><br /><br /><br /><br /><br /><br /><br />&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p><br /></p><p><br /></p><p>然后选择图片大小。互动百科词条中有大图和小图两种可供选择。&nbsp;<br /></p><p>图片对齐方式包括：居左和居右两种。居左是指图片在左，文字在右的排版方式；反之，居右，是指图片在右文字在左。 <br />如果对图片位置不满意可以选中图片框，然后拖动到满意的位置即可。 <br />图片的格式必须是.gif或者.jpg格式。</p><div class="hd"  wiki_tmml="">如何插入表格？ </div><p>将光标放在要插入表格的地方之后，选择“插入表格”，如下图： <br /></p><div class="img img_l" style="width:300px;" id="wrap-img-4"><a title="插入表格" href="uploads/201612/14824788446TqN1ZRx.png" target="_blank"><img title="插入表格" alt="插入表格" src="uploads/201612/14824788446TqN1ZRx_s.png" id="img-4" /></a><strong>插入表格</strong></div><p><br /></p><p><br /><br /><br /><br /><br /><br /><br />&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>在弹出的插入表格菜单选择表格的行数、列数。点击后表格就生成了。<br />如果还想对表格进行调整和改变，可以使用“表格菜单”调整。 <br />使用这些功能可以进行修改表格行属性、单元格属性、删除、增加行（或列）等操作。 </p><div class="hd"  wiki_tmml="">如何插入特殊符号？</div><p>&nbsp;将光标放在要插入符号的地方之后，选择“特殊符号”按钮，如下图： </p><div class="img img_l" style="width:300px;" id="wrap-img-5"><a title="插入特殊符号" href="uploads/201612/1482478870vFZ5EDfm.png" target="_blank"><img title="插入特殊符号" alt="插入特殊符号" src="uploads/201612/1482478870vFZ5EDfm_s.png" id="img-5" /></a><strong>插入特殊符号</strong></div><p><br /></p><p><br /><br /><br /><br /><br />&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>在弹出菜单选择想要插入的符号，不存在的符号可以到MS Word中寻找，再粘贴到编辑器中。 </p>',
      'author' => 'admin',
      'authorid' => '1',
      'time' => '07-30 16:38',
      'lastedit' => '12-23 15:41',
      'lasteditor' => 'admin',
      'lasteditorid' => '1',
      'views' => '6',
      'edits' => '2',
      'editions' => '2',
      'visible' => '1',
      'locked' => '0',
      'iscreate' => false,
      'rawtitle' => '创建/协作',
      'shorttitle' => '创建/协作',
      'category' => NULL,
      'img' => 'uploads/201612/1482478750CCuUTIBW_s.png',
    ),
    1 => 
    array (
      'did' => '34',
      'cid' => '0',
      'letter' => 'x',
      'title' => '协作者',
      'tag' => '',
      'summary' => '什么是协作者？ 词条的协作者是参与该词条编辑的所有用户。 什么是最新协作者？ 最新协作者是指最近一个参与该词条编辑的用户。在词条正文页右侧，可以查看到该词条当前的最新贡献者。（如下图） 
最新协作者',
      'content' => '<p><strong>什么是协作者？ <br /></strong>词条的协作者是参与该词条编辑的所有用户。 <br /><br /><strong>什么是最新协作者？</strong><br />最新协作者是指最近一个参与该词条编辑的用户。在词条正文页右侧，可以查看到该词条当前的最新贡献者。（如下图） <br /><br /></p><p><div class="img img_l" style="width:238px;" id="wrap-img-0"><a title="协作者" href="uploads/201612/1482478686dj6P24lB.png" target="_blank"><img title="协作者" alt="协作者" src="uploads/201612/1482478686dj6P24lB_s.png" id="img-0" /></a><strong>协作者</strong></div><br /></p>',
      'author' => 'admin',
      'authorid' => '1',
      'time' => '07-30 17:20',
      'lastedit' => '12-23 15:38',
      'lasteditor' => 'admin',
      'lasteditorid' => '1',
      'views' => '6',
      'edits' => '1',
      'editions' => '1',
      'visible' => '1',
      'locked' => '0',
      'iscreate' => false,
      'rawtitle' => '协作者',
      'shorttitle' => '协作者',
      'category' => NULL,
      'img' => 'uploads/201612/1482478686dj6P24lB_s.png',
    ),
    2 => 
    array (
      'did' => '33',
      'cid' => '0',
      'letter' => 'l',
      'title' => '历史版本',
      'tag' => '',
      'summary' => '什么是历史版本？ 每个编辑者编辑词条后，并不是直接覆盖词条原有内容，而是将原有内容保存，将新增或修改的内容保存并于原因内容合并保存为新版本。这样，每一次编辑都会产生新的版本，一个词条的所有版本即为该词条',
      'content' => '<p><strong>什么是历史版本？</strong><br />每个编辑者编辑词条后，并不是直接覆盖词条原有内容，而是将原有内容保存，将新增或修改的内容保存并于原因内容合并保存为新版本。这样，每一次编辑都会产生新的版本，一个词条的所有版本即为该词条的历史版本。 <br /><br /><strong>如何查看历史版本？</strong><br />在每个词条正文页的右侧点击“共有×个版本”（如下图），即可进入该词条的历史版本页。</p><p><div class="img img_l" style="width:287px;" id="wrap-img-0"><a title="查看历史版本" href="uploads/201612/14824786397u0dU44N.png" target="_blank"><img title="查看历史版本" alt="查看历史版本" src="uploads/201612/14824786397u0dU44N_s.png" id="img-0" /></a><strong>查看历史版本</strong></div>&nbsp; <br /></p><p>在历史版本页里可以查看各版本基本信息，如编辑时间、编辑者、版本改动及修改原因等情况。 <br /><br /></p>',
      'author' => 'admin',
      'authorid' => '1',
      'time' => '07-30 16:55',
      'lastedit' => '12-23 15:37',
      'lasteditor' => 'admin',
      'lasteditorid' => '1',
      'views' => '7',
      'edits' => '3',
      'editions' => '3',
      'visible' => '1',
      'locked' => '0',
      'iscreate' => false,
      'rawtitle' => '历史版本',
      'shorttitle' => '历史版本',
      'category' => NULL,
      'img' => 'uploads/201612/14824786397u0dU44N_s.png',
    ),
    3 => 
    array (
      'did' => '36',
      'cid' => '0',
      'letter' => 'x',
      'title' => '相关词条',
      'tag' => '',
      'summary' => '相关词条
什么是相关词条？ 相关词条就是与一个词条相关的其他词条。在词条正文页的右侧（如下图）可查看和完善相关词条。 
 
 
如何完善相关词条？ 在词条正文页右侧的相关词条列表，点击完善，进入',
      'content' => '<div class="img img_l" style="WIDTH: 181px" id="wrap-img-0"><a title="相关词条" href="uploads/201007/1280484381eiJRbLHZ.gif" target="_blank"><img title="相关词条" alt="相关词条" src="uploads/201007/1280484381eiJRbLHZ_s.gif" id="img-0" /></a><strong>相关词条</strong></div><p>什么是相关词条？ <br />相关词条就是与一个词条相关的其他词条。在词条正文页的右侧（如下图）可查看和完善相关词条。 <br /><br /><br /><br /><br /><br /><br /><br /></p><p>&nbsp;</p><p>&nbsp;</p><p><strong>如何完善相关词条？</strong><br />在词条正文页右侧的相关词条列表，点击完善，进入相关词条操作页面。你可以为该词条添加10个相关词条，在词条名后面还可以添加该词条的描述，如中国的相关词条北京，描述为中国的首都。（如下图） </p><p><br /></p><div class="img img_l" style="WIDTH: 291px" id="wrap-img-1"><a title="相关词条" href="uploads/201007/1280484396d6hN0GoI.gif" target="_blank"><img title="相关词条" alt="相关词条" src="uploads/201007/1280484396d6hN0GoI_s.gif" id="img-1" /></a><strong>完善相关词条</strong></div><p><br /><br /><br /><br /><br /><br />&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>完成后点击提交，就可以看到你刚刚完善的相关词条了。 <br /><br /></p>',
      'author' => 'admin',
      'authorid' => '1',
      'time' => '07-30 18:06',
      'lastedit' => '12-23 15:36',
      'lasteditor' => 'admin',
      'lasteditorid' => '1',
      'views' => '30',
      'edits' => '1',
      'editions' => '1',
      'visible' => '1',
      'locked' => '0',
      'iscreate' => false,
      'rawtitle' => '相关词条',
      'shorttitle' => '相关词条',
      'category' => NULL,
      'img' => 'uploads/201007/1280484381eiJRbLHZ_s.gif',
    ),
    4 => 
    array (
      'did' => '24',
      'cid' => '0',
      'letter' => 'z',
      'title' => '注册/登录',
      'tag' => '',
      'summary' => '如何注册 初次访问互动百科的浏览者，可以通过右上角的用户中心进入用户注册页面。（见下图） 
注册
 
 
 
 
 
 
 
你只需花费几十秒时间，填写个人信息。即可成功注册',
      'content' => '<div class="hd"  wiki_tmml="">如何注册 </div><p><br />初次访问互动百科的浏览者，可以通过右上角的用户中心进入用户注册页面。（见下图） <br /></p><p><div class="img img_l" style="width:300px;" id="wrap-img-0"><a title="注册与登录" href="uploads/201612/1482478379QfzdcM6m.png" target="_blank"><img title="注册与登录" alt="注册与登录" src="uploads/201612/1482478379QfzdcM6m_s.png" id="img-0" /></a><strong>注册与登录</strong></div><br /></p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p><br />&nbsp;</p><p>你只需花费几十秒时间，填写个人信息。即可成功注册成为本站用户。 <br /></p><div class="hd"  wiki_tmml="">如何登录</div><p><br />已注册的本站用户，再次访问本站是，在右上角登录框输入注册邮箱、密码和验证码，即可登录本站点 <br /></p>',
      'author' => 'admin',
      'authorid' => '1',
      'time' => '07-30 15:03',
      'lastedit' => '12-23 15:33',
      'lasteditor' => 'admin',
      'lasteditorid' => '1',
      'views' => '3',
      'edits' => '1',
      'editions' => '1',
      'visible' => '1',
      'locked' => '0',
      'iscreate' => false,
      'rawtitle' => '注册/登录',
      'shorttitle' => '注册/登录',
      'category' => NULL,
      'img' => 'uploads/201612/1482478379QfzdcM6m_s.png',
    ),
    5 => 
    array (
      'did' => '21',
      'cid' => '0',
      'letter' => 'W',
      'title' => 'wiki',
      'tag' => '',
      'summary' => '什么是Wiki（维客）？
Wiki是一种多人协作的写作工具，读者即作者。互动百科由所有注册用户共同维护，每个人都可以通过编写百科词条对任何主题进行扩展和探讨。Wiki依靠众人不断地更新修改，开创了一种',
      'content' => '<p>什么是Wiki（维客）？<br />
Wiki是一种多人协作的写作工具，读者即作者。互动百科由所有注册用户共同维护，每个人都可以通过编写百科词条对任何主题进行扩展和探讨。Wiki依靠众人不断地更新修改，开创了一种借助互联网创建、积累、完善和分享知识的全新模式。<br /></p><div class="hd  wiki_tmml">定义</div><div class="img img_r" style="width: 300px;" id="wrap-img-0"><a title="wiki" href="http://tupian.hudong.com/a2_51_00_01300000258678125298008205520_jpg.html" target="_blank"><img title="wiki" alt="wiki" src="http://a2.att.hudong.com/51/00/01300000258678125298008205520_s.jpg" id="img-0" /></a><strong>wiki</strong></div><p>Wiki的历史还不长，无论是Wiki概念自身，还是相关软件系统的特性，还都在热烈的讨论中；所以怎样的一个站点才能称得上是一个Wiki系统还是有争议的。与Wiki相关最近出现的技术还有blog，它们都降低了<a class="innerlink" title="超文本" href="index.php?doc-innerlink-%E8%B6%85%E6%96%87%E6%9C%AC">超文本</a>写作和发布的难度。这两者都与内容管理系统关系紧密。第一个 Wiki 网站诞生于1995年，Ward Cunningham 创建的，作为<a class="innerlink" title="波特兰" href="index.php?doc-innerlink-%E6%B3%A2%E7%89%B9%E5%85%B0">波特兰</a>的模式仓库的模式定义和讨论的交互性场所: http://c2.com/ppr/；而其根源可以上述到1972年<a class="innerlink" title="卡耐基·梅隆大学" href="index.php?doc-innerlink-%E5%8D%A1%E8%80%90%E5%9F%BA%C2%B7%E6%A2%85%E9%9A%86%E5%A4%A7%E5%AD%A6">卡耐基·梅隆大学</a>的 ZOG 数据库系统。<br /><br />1995年Ward Cunningham为了方便模式社群的交流建立了一个工具－波特兰模式知识库（Portland Pattern Repository）。在建立这个系统的过程中，Ward Cunningham创造了Wiki的概念和名称，并且实现了支持这些概念的服务系统。这个系统是最早的Wiki系统。从1996年至2000年间，波特兰模式知识库围绕着面向社群的协作式写作，不断发展出一些支持这种写作的辅助工具，从而使Wiki的概念不断得到丰富。同时Wiki的概念也得到了传播，出现了许多类似的网站和软件系统。<br /><br />1995年3月25日 维客历史正式开始<br />1995年5月1日 “模式名单的革新”发布。这是世界上第一个维客网站，是对“波特兰模式知识库”的一个自动 补充。网站发布之初，便立即在“模式社区”（pattern community）中获得成功。 <br />该网站定位的演变历程：<br />1995年 模式社区及其他们的资源和应用；<br />1996年 普通设计、建筑以及方法；<br />1997年 从人和组织的角度看待规划设计；<br />1998年 偏激的规划设计；<br />2000年 维客本身；<br />2003年 维客、社会学等。<br />社区引入并保留的概念创新：<br />1994年 “近期访问者”（RecentVisitors）、“人物索引”（PeopleIndex）；<br />1995年 “并不时新的变化”（NotSoRecentChanges）；<br />1996年 “丝线模式”（ThreadMode）、“丝线模式无益”（ThreadModeConsideredHarmful ） <br />1996年 “维客分类”（WikiCategories）；<br />1997年 “路线图”（RoadMaps）；<br />1999年 “更改概要”（ChangeSummary）（虽未继续下去，但却带来了快速变化〔QuickChanges〕）；<br />1999年 “随机页面”（RandomPages）；<br />1999年 “（月度）变化”（ChangesIn ）页面出现（“并不时新的变化”分离出去 并逐渐消亡）；<br />2000年 “搜索助手”（SearchHelper）</p><div class="hd  wiki_tmml">特点</div><p><strong>使用方便</strong><br />维护快捷：快速删除、存取、更改超文本页面（这也是为什幺叫作“wiki wiki”的原因）。<br />格式简单：用简单的格式标记来取代 HTML 的复杂格式标记。（类似所见即所得的风格）&nbsp;<br />链接方便：通过简单标记，直接以关键字名来建立链接(页面、外部连接、图像等)。&nbsp;<br />命名平易：关键字名就是页面名称，并且被置于一个单层、平直的名空间中。</p><p><strong>有组织<br /></strong>自组织的：同页面的内容一样，整个超文本的组织结构也是可以修改、演化的。&nbsp;<br />可汇聚的：系统内多个内容重复的页面可以被汇聚于其中的某个，相应的链接结构也随之改变。</p><p><strong>可增长<br /></strong>可增长：页面的<a class="innerlink" title="链接" href="index.php?doc-innerlink-%E9%93%BE%E6%8E%A5">链接</a>目标可以尚未存在，通过点击链接，我们可以创建这些页面，从而使系统得到增长。&nbsp;<br />修订历史：记录页面的修订历史，页面的各个版本都可以被获取。 </p><p><strong>开放性<br /></strong>开放的：社群的成员可以任意创建、修改、删除页面。&nbsp;<br />可观察：系统内页面的变动可以被访问者观察到。</p><div class="hd  wiki_tmml">与blog区别</div><table id="jqe-table-0"><tbody><tr><td><strong>Wiki</strong>站点一般都有着一个严格的共同关注，Wiki的主题一般是明确的坚定的。Wiki站点的内容要求着高度相关性。最其确定的主旨，任何写作者和参与者都应当严肃地遵从。Wiki的协作是针对同一主题作外延式和内涵式的扩展，将同一个问题谈得很充分很深入。</td><td><a class="innerlink" title="Blog" href="index.php?doc-innerlink-Blog">Blog</a>是一种无主题变奏，一般来说是少数人（大多数情况下是一个人）的关注的蔓延。一般的Blog站点都会有一个主题，凡是这个主旨往往都是很松散的，而且一般不会去刻意地控制内容的相关性。</td></tr><tr><td><strong>Wiki</strong>非常适合于做一种 “All about something”的站点。个性化在这里不是最重要的，信息的完整性和充分性以及权威性才是真正的目标。Wiki由于其技术实现和含义的交织和复杂性，如果你漫无主题地去发挥，最终连建立者自己都会很快的迷失。</td><td><strong>Blog</strong>注重的是个人的思想（不管多么不成熟，多么地匪夷所思），个性化是Blog的最重要特色。Blog注重交流，一般是小范围的交流，通过访问者对一些或者一篇Blog文章的评论和交互。</td></tr><tr><td><strong>Wiki</strong>使用最多也最合适的就是去共同进行文档的写作或者文章/书籍的写作。特别是技术相关的（尤以程序开发相关的）FAQ，更多的也是更合适地以Wiki来展现。</td><td><strong>Blog</strong>也有协作的意思，但是协作一般是指多人维护，而维护者之间可能着力于完全不同的内容。这种协作在内容而言是比较松散的。任何人，任何主体的站点，你都可以以Blog方式展示，都有它的生机和活力。</td></tr></tbody></table><div class="hd  wiki_tmml">技术规范</div><p>wiki是任何人都可以编辑的网页。在每个正常显示的页面下面都有一个编辑按钮，点击这个按钮你就可以编辑页面了。有些人要问：任何人都可以编辑？那不是乱套了么？其实不然，wiki体现了一种哲学思想：“<strong>人之初，性本善</strong>”。wiki认为不会有人故意破坏wiki网站，大家来编辑网页是为了共同参与。虽然如此，还是不免有很多好奇者无意中更改了wiki网站的内容，那么为了维持网站的正确性，wiki在技术上和运行规则上做了一些规范，做到既持面向大众公开参与的原则又尽量降低众多参与者带来的风险。这些技术和规范包括：</p><p>1、保留网页每一次更动的版本：即使参与者将整个页面删掉，管理者也会很方便地从纪录中恢复最正确的页面版本。<br /><br />2、页面锁定：一些主要页面可以用锁定技术将内容锁定，外人就不可再编辑了。（虽然wiki都有这个功能，但我看到使用它的甚少，这可能跟wiki倡导的精神相违背吧）。<br /><br />3、版本对比：wiki站点的每个页面都有更新纪录，任意两个版本之间都可以进行对比，wiki会自动找出他们的差别。<br /><br />4、更新描述：你在更新一个页面的时候可以在描述栏中写上几句话，如你更新内容的依据、或是跟管理员的对话等。这样，管理员就知道你更新页面的情况。<br /><br />5、IP禁止：尽管wiki倡导“人之初，性本善”，人人都可参与，但破坏者、恶作剧者总是存在的，wiki有纪录和封存IP的功能，将破坏者的IP纪录下来他就不能在胡作非为了。<br /><br />6、Sand Box(沙箱)测试：一般的wiki都建有一个Sand Box的页面，这个页面就是让初次参与的人先到Sand Box页面做测试，Sand Box与普通页面是一样的，这里你可以任意涂鸦、随意测试。<br /><br />7、编辑规则：任何一个开放的wiki都有一个编辑规则，上面写明大家建设维护wiki站点的规则。没有规矩不成方圆的道理任何地方都是适用的。</p><div class="hd  wiki_tmml">WIKI词条编辑步骤 </div><p><br /><br /><br /><br />·第一步，对几个常用的在线百科网站进行了解，注册用户，了解编辑说明，注意各网站对词条编写及修改的规则。 <br /><br /><br /><br />·第二步，确定自己希望编写的词条。可以选择自己熟悉的人事物、行业知识、热点事件等。 <br /><br /><br /><br />·第三步，找到自己希望编辑词条所在目录并尝试性编辑词条，可以对已经存在的词条提交修改，尝试性增加自己希望的内容及网址链接，进一步熟悉该网站的规则及审核周期，推测管理员的偏好等。 <br /><br /><br /><br /></p><div class="hd  wiki_tmml">代表系统</div><p>&nbsp;WIKI概念的发明人是Ward Cunningham，该词来源于<a class="innerlink" title="夏威夷" href="index.php?doc-innerlink-%E5%A4%8F%E5%A8%81%E5%A4%B7">夏威夷</a>语的“wee kee wee kee”，原本是“快点快点” (quick)的意思。 </p><p><strong>最早的Wiki系统</strong><br />1995年沃德·坎宁安为了方便模式社群的交流建立了一个工具－波特兰模式知识库（Portland Pattern Repository）。在建立这个系统的过程中，沃德·坎宁安创造了Wiki的概念和名称，并且实现了支持这些概念的服务系统。这个系统是最早的Wiki系统。从1996年至2000年间，波特兰模式知识库围绕着面向社群的协作式写作，不断发展出一些支持这种写作的辅助工具，从而使Wiki的概念不断得到丰富。同时Wiki的概念也得到了传播，出现了许多类似的网站和软件系统。 </p><p><strong>世界上最大的Wiki系统</strong><br /><a class="innerlink" title="维基百科" href="index.php?doc-innerlink-%E7%BB%B4%E5%9F%BA%E7%99%BE%E7%A7%91">维基百科</a>是目前世界上最大的Wiki系统，它是一个基于Wiki和GNU FDL（GFDL）的百科全书网站系统，致力于创建内容开放的百科全书。该系统于2001年1月投入运行，2001年2月超过1,000条条目，2001年7月超过10,000条条目，至2005年3月，英文条目已经超过500,000条。维基百科条目的迅速增长说明了维基百科系统的健壮，也说明了Wiki的概念是经得起验证的。 </p><div class="hd  wiki_tmml">自主程序</div><p>开源的WIKI建站系统可以方便的建立自己的wiki网站，常见的建站系统有：wikimedia、HDwiki。<br />HDwiki是<a class="innerlink" title="互动在线" href="index.php?doc-innerlink-%E4%BA%92%E5%8A%A8%E5%9C%A8%E7%BA%BF">互动在线</a>开发的一款针对中文百科的建站系统，具有良好的性能、丰富的扩展接口、简便的操作方法等等优势。越来越受到中国站长的青睐。<br />网址：http://kaiyuan.hudong.com/</p><div class="hd  wiki_tmml">国内百科<div class="img img_r" style="width:300px;" id="wrap-img-1"><a title="互动百科" href="uploads/201612/1482478273fFzcWBfu.jpg" target="_blank"><img title="互动百科" alt="互动百科" src="uploads/201612/1482478273fFzcWBfu_s.jpg" id="img-1" /></a><strong>互动百科</strong></div></div><p>互动百科：<a href="http://www.baike.com/">http://www.baike.com/</a><br />艺术百科：http://wiki.artcomb.com/<br />协作百科：http://www.knowtive.com/<br />天魔维客网：http://wiki.tianmo.com.cn/<br />康Q网：http://www.kangq.com/<br />中华百科：http://www.wikichina.com/<br />IT Wiki：http://wiki.ccw.com.cn/<br />网络天书：http://www.cnic.org/<br />维库：http://www.wikilib.com/<br />CookBus Wiki：http://www.cookbus.com/wiki<br />天下维客：http://www.allwiki.com/<br />美食客：http://www.mskee.com/wiki <br />网络大典WIKI：http://wiki.networkdictionary.cn/<br />MBA智库百科：http://www.mbalib.com/</p>',
      'author' => 'admin',
      'authorid' => '1',
      'time' => '07-30 12:07',
      'lastedit' => '12-23 15:31',
      'lasteditor' => 'admin',
      'lasteditorid' => '1',
      'views' => '3',
      'edits' => '1',
      'editions' => '1',
      'visible' => '1',
      'locked' => '0',
      'iscreate' => false,
      'rawtitle' => 'wiki',
      'shorttitle' => 'wiki',
      'category' => NULL,
      'img' => 'http://a2.att.hudong.com/51/00/01300000258678125298008205520_s.jpg',
    ),
  ),
  'hottag' => 
  array (
    0 => 
    array (
      'tagname' => '考拉',
      'tagcolor' => '',
    ),
    1 => 
    array (
      'tagname' => '鲸',
      'tagcolor' => '',
    ),
    2 => 
    array (
      'tagname' => 'HDwiki',
      'tagcolor' => '',
    ),
    3 => 
    array (
      'tagname' => '鼬',
      'tagcolor' => '',
    ),
    4 => 
    array (
      'tagname' => '小熊猫',
      'tagcolor' => '',
    ),
    5 => 
    array (
      'tagname' => '大耳狐',
      'tagcolor' => 'red',
    ),
    6 => 
    array (
      'tagname' => '紫玉兰',
      'tagcolor' => 'red',
    ),
    7 => 
    array (
      'tagname' => '驯鹿',
      'tagcolor' => 'red',
    ),
    8 => 
    array (
      'tagname' => '侏绿鱼狗',
      'tagcolor' => 'red',
    ),
    9 => 
    array (
      'tagname' => '七彩文鸟',
      'tagcolor' => '',
    ),
    10 => 
    array (
      'tagname' => '钩嘴翠鸟',
      'tagcolor' => 'red',
    ),
    11 => 
    array (
      'tagname' => '丹顶鹤',
      'tagcolor' => '',
    ),
    12 => 
    array (
      'tagname' => '云雀',
      'tagcolor' => 'red',
    ),
    13 => 
    array (
      'tagname' => '仙居鸡',
      'tagcolor' => 'red',
    ),
    14 => 
    array (
      'tagname' => '伊力格氏金刚鹦鹉',
      'tagcolor' => 'red',
    ),
    15 => 
    array (
      'tagname' => '棕腰歌百灵',
      'tagcolor' => '',
    ),
    16 => 
    array (
      'tagname' => '索科罗苇鹪鹩',
      'tagcolor' => '',
    ),
    17 => 
    array (
      'tagname' => '八音鸟',
      'tagcolor' => '',
    ),
  ),
  'friendlink' => 
  array (
    0 => 
    array (
      'id' => '1',
      'name' => '互动百科',
      'url' => 'http://www.baike.com',
      'logo' => '',
      'description' => '互动百科官网',
      'displayorder' => '0',
    ),
  ),
  'recentcommentlist' => 
  array (
    0 => 
    array (
      'image' => 'style/default/user.jpg',
      'id' => '112',
      'did' => '58',
      'comment' => '新增访问频率限制，可以根据IP或用户标识对某个功能进行在指定时间范围内的可访问次数限制',
      'reply' => '',
      'author' => 'admin',
      'authorid' => '1',
      'oppose' => '0',
      'aegis' => '0',
      'time' => '12-23 15:44',
      'tipcomment' => '新增访问频率限制，可以根据...',
    ),
    1 => 
    array (
      'image' => 'style/default/user.jpg',
      'id' => '111',
      'did' => '58',
      'comment' => '新增CSRF（Cross-site request forgery跨站请求伪造）防范',
      'reply' => '',
      'author' => 'admin',
      'authorid' => '1',
      'oppose' => '0',
      'aegis' => '0',
      'time' => '12-23 15:44',
      'tipcomment' => '新增CSRF（Cross-...',
    ),
    2 => 
    array (
      'image' => 'style/default/user.jpg',
      'id' => '110',
      'did' => '58',
      'comment' => '功能精简，让移动端更加轻量化',
      'reply' => '',
      'author' => 'admin',
      'authorid' => '1',
      'oppose' => '0',
      'aegis' => '0',
      'time' => '12-23 15:43',
      'tipcomment' => '功能精简，让移动端更加轻量...',
    ),
    3 => 
    array (
      'image' => 'style/default/user.jpg',
      'id' => '109',
      'did' => '58',
      'comment' => 'ios、安卓、win多机型适配',
      'reply' => '',
      'author' => 'admin',
      'authorid' => '1',
      'oppose' => '0',
      'aegis' => '0',
      'time' => '12-23 15:43',
      'tipcomment' => 'ios、安卓、win多机型...',
    ),
    4 => 
    array (
      'image' => 'style/default/user.jpg',
      'id' => '108',
      'did' => '58',
      'comment' => 'PC端内容自动识别适应至移动端',
      'reply' => '',
      'author' => 'admin',
      'authorid' => '1',
      'oppose' => '0',
      'aegis' => '0',
      'time' => '12-23 15:43',
      'tipcomment' => 'PC端内容自动识别适应至移...',
    ),
  ),
);
?>