<?php
return array (
  'newslist' => 
  array (
    1526550578 => '<a href=\'index.php?user-space-1\' class=\'red\'>admin</a>刚刚加入了我的HDWiki',
    1482478879 => '<a href=\'index.php?user-space-1\' class=\'red\'>admin</a>对词条<a href="index.php?doc-view-30" target="_blank">创建/协作</a>进行了编辑，将使更多人因此受益。',
    1482477441 => '<a href=\'index.php?user-space-1\' class=\'red\'>admin</a>对词条<a href="index.php?doc-view-58" target="_blank">HDwiki6.0</a>进行了编辑，将使更多人因此受益。',
    1482477293 => '<a href=\'index.php?user-space-1\' class=\'red\'>admin</a>对词条<a href="index.php?doc-view-58" target="_blank">HDwiki6.0</a>进行了编辑，将使更多人因此受益。',
    1280484410 => '<a href=\'index.php?user-space-1\' class=\'red\'>admin</a>对词条<a href="index.php?doc-view-36" target="_blank">相关词条</a>进行了编辑，将使更多人因此受益。',
    1280481637 => '<a href=\'index.php?user-space-1\' class=\'red\'>admin</a>对词条<a href="index.php?doc-view-34" target="_blank">协作者</a>进行了编辑，将使更多人因此受益。',
    1280480195 => '<a href=\'index.php?user-space-1\' class=\'red\'>admin</a>对词条<a href="index.php?doc-view-33" target="_blank">历史版本</a>进行了编辑，将使更多人因此受益。',
    1280479100 => '<a href=\'index.php?user-space-1\' class=\'red\'>admin</a>对词条<a href="index.php?doc-view-30" target="_blank">创建/协作</a>进行了编辑，将使更多人因此受益。',
    1280473408 => '<a href=\'index.php?user-space-1\' class=\'red\'>admin</a>对词条<a href="index.php?doc-view-24" target="_blank">注册/登录</a>进行了编辑，将使更多人因此受益。',
    1280462873 => '<a href=\'index.php?user-space-1\' class=\'red\'>admin</a>对词条<a href="index.php?doc-view-21" target="_blank">Wiki</a>进行了编辑，将使更多人因此受益。',
    1280224373 => '<a href=\'index.php?user-space-1\' class=\'red\'>admin</a>对词条<a href="index.php?doc-view-19" target="_blank">HDwiki</a>进行了编辑，将使更多人因此受益。',
  ),
);
?>